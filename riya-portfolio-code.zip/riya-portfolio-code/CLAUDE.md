# CLAUDE.md

Conventions for **AI coding assistants** (Claude Code / Cursor / Copilot, etc.) working in this repo. This is **Riya Gandhi's portfolio**, built on the open-source "sen-3d-resume" template (**React Three Fiber + TypeScript**): a fixed 3D background (her character on a turntable, turned by scroll / drag) plus scrollable HTML content in front (hero → rail of chapters → works gallery → contact). `README.md` is still the upstream template's README; this file describes the repo as it is now.

## Repo layout (read this first)

The repo has three parts:

- **[`web/`](web)** — the front-end app (every code convention in this file lives here).
- **[`blender/`](blender)** — the upstream template's 3D source (`sen.blend`). Not used by this site.
- **[`tutor/`](tutor)** — the upstream template's tutorials (deployment etc., in Chinese).
- **`_template-originals/`** — the template author's personal assets (character model, logos, covers), moved out of `web/`. Git-ignored; they are not MIT-licensed (see `NOTICE`) — never publish them.

**Every code / asset path below is relative to `web/`** (e.g. `src/App.tsx` means `web/src/App.tsx`), and npm commands run inside `web/`; docs like `LICENSE` / `NOTICE` / `CLAUDE.md` sit at the repo root.

## Commands

```bash
cd web             # all front-end commands run inside web/
npm install
npm run dev        # dev server at http://localhost:5173 (vite)
npm run build      # type-check + bundle to dist/
npm run preview    # preview the build output
npm run typecheck  # type-check only (tsc -b)
npm run lint       # ESLint (lightweight; `any` in the scene is allowed)
```

No tests. Linting is `npm run lint` (lightweight ESLint, `no-explicit-any` disabled to fit the scene code), type-checking is `npm run typecheck`; after editing, verify visually in the browser via `npm run dev`.

## Architecture

- **Pure front-end SPA**: `index.html` → `src/main.tsx` → `src/App.tsx` (one fixed `<Canvas>` 3D background + a scrollable HTML overlay). No backend, no router.
- **3D background**: `src/scene/Scene.tsx` — one subject (the character) on a **true 360° turntable**: 140 cut-out frames of one full turn in `public/character/` (real footage, nothing mirrored), listed with their angles in `src/data/turntable.json`. Each frame also has an optical-flow map to the next one; the shader uses it to slide one frame into the next, so the turn is continuous at any speed (no stepping, no cross-fade ghosting), and she eases onto the nearest real frame when she stops. She turns only when the page scrolls (`turn.auto: 'off'`, `turn.drag: false`), always the same way, a whole number of turns over the page — front at the top, front at the bottom. The site uses Lenis inertial smooth scrolling in `App.tsx`. `prefers-reduced-motion` → still front frame. Unlit (custom `shaderMaterial`): no lights, no HDR.
- **Subject slot**: she holds a fixed place on screen — left ~45% on wide layouts with her base running off the bottom edge; on phones (≤640px, same breakpoint in `Scene.tsx` `NARROW` and `styles.css`) the upper part of the screen, with `.base-fade` dissolving her base. Text never covers her on wide layouts: hero copy, rail and contact all share one right-hand column (`min(500px, 46vw)`).
- **Scroll content**: `Hero` in `App.tsx` (copy in `COPY`) → `src/ui/Resume.tsx` (the rail: numbers, about, capabilities, framework, career, case study, education — copy in `src/data/resume.ts`) → `src/ui/Works.tsx` (pinned horizontal gallery + detail modal — data in `src/data/works.ts`) → `src/ui/Contact.tsx`.
- **Navigation**: `src/ui/Nav.tsx` (inline row on the first screen + Menu sheet); targets are elements tagged `data-nav`, scrolled to by `src/ui/scrollTo.ts` (which knows how to land on a card inside the pinned gallery).
- **Overlays**: `LoadingScreen` (masks the screen until every frame is loaded), `NoiseOverlay` (film grain), scrim / frosted rail / works veil / hero frame (all in `App.tsx`).
- **Global state**: `src/store.ts` (zustand): which work detail is open.

## TypeScript conventions

This project is TypeScript (`strict` on). `App` / `ui` / `data` / `store` are fully typed; the imperative Three.js code in `Scene.tsx` (mesh refs, canvas contexts, camera) is loosened with a few `any`s — follow that style, don't hard-type the 3D internals just to eliminate `any`. Make sure `npm run typecheck` passes after edits.

## Scene parameters (look here to change the look)

Every tunable in the scene is a **plain constant** at the top of the relevant component in `Scene.tsx` — edit the values directly, there is no tweak panel or config file:

- `GradientBackground`: `top` / `bottom` backdrop colours (keep `--scene-bg` in `styles.css` equal to `bottom`).
- `Subject`: `turn` (auto mode `loop` / `pingpong`, sweep range, speed, drag & scroll sensitivity, resume delay), `slot` (where she sits on screen), `bob`.
- `Doodles`: palette and the list of floating doodles. `Post`: depth-of-field / bloom.
- Module level: `FRAMES` (from `src/data/turntable.json`), `subject` (size, face height) and the turntable shader.

In dev, `__turntable.hold(65)` / `__turntable.release()` in the console parks her at an angle.

### Character frames

`scripts/prepare-character.py <turntable.mp4> public/character src/data/turntable.json` turns a turntable video into what the scene plays. It needs a locked-off camera, a flat background and a video that loops one full turn (`START` / `PERIOD` at the top of the script — currently frames 144–283 of a 140-frame loop). Per frame it writes `t###.webp` (cut-out, fixed crop — no per-frame re-alignment, so the motion is exactly the video's), `s###.webp` (0.7× for phones) and `f###.png` (optical flow to the next frame, red/green channels, ±`flowMax` px); the manifest holds frame names, yaw, crop size and flow range. The source turn eases in and out, so yaw is paced by picture change, not an even split. Source video: `~/Downloads/Untitled_Scene_10-13_04_08_38_20261013094109.mp4`.

Don't replace the flow interpolation with a plain blend of two frames: that shows as a double image, which Riya has ruled out.

## Works content system (look here to change content)

- **List**: `src/data/works.ts` — section / work titles, meta, tags, external links, and cover mapping (`SECTION_COVERS`). Pure data; `Works.tsx` only renders it.
- **Detail**: one `src/content/works/<slug>.md` per work (frontmatter + markdown, spec in `src/data/workDocs.ts`), linked via the `slug` on each item in works.ts.
  - Items without an md fall back to their own label / description; `example.md` is the template (its slug matches no item).
- **Media**: put images / videos in `public/works/<slug>/` and reference them from the md with `/works/...` paths (`Works.tsx` rewrites them against `BASE_URL`). YouTube videos need no files: set `video: <id>` on the item / in the md frontmatter.

## Rendering pipeline notes

- Post-processing is in `Scene.tsx`'s `<EffectComposer>`: order is DepthOfField → Bloom → SMAA; mind the order when changing effects.
- The character and doodle materials are `transparent` with a small `alphaTest` so clear pixels don't write depth (keeps depth-of-field correct).
- `base: './'` (`vite.config.ts`): output uses relative paths, deployable to any subdirectory; public assets are joined with `import.meta.env.BASE_URL`.

## Where to edit content

- First screen: `COPY` in `App.tsx`. Rail chapters: `src/data/resume.ts`. Works gallery: `src/data/works.ts` + `src/content/works/*.md`. Contact / footer: `CONTACT` in `src/ui/Contact.tsx`. Page title / meta: `index.html`.
- Source of the copy is the previous site at itsriyagandhi.com; keep wording verbatim unless asked to rewrite.

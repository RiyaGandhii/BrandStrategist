#!/usr/bin/env python3
"""Turn a turntable video of the character into what the 3D scene plays.

    pip install pillow numpy scipy opencv-python-headless
    python3 scripts/prepare-character.py turntable.mp4 public/character src/data/turntable.json

Assumes a locked-off camera, a flat background, and a video that loops one full turn
every PERIOD frames, starting on the front view at frame START (measure both once per
video: the frame most similar to frame START + PERIOD is START itself).

For each of the PERIOD frames it writes, into public/character/:

    t###.webp   the frame, cut out of the background (same fixed crop for every frame,
                so the turn is exactly the one in the video — nothing is re-aligned)
    s###.webp   the same at SMALL scale, for phones
    f###.png    optical flow from this frame to the next (wrapping), in the red / green
                channels: how far each part of her moves, so the scene can slide
                smoothly from one frame to the next instead of stepping

and the manifest (frame names, the angle each shows, crop size, flow scale). The turn
in the video eases in and out, so angles come from how much the picture changes per
frame rather than from an even split.
"""
import sys, json, glob, os
import cv2
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

SRC, OUT, MANIFEST = sys.argv[1:4]
START, PERIOD = 144, 140   # first frame of one clean loop (front view); frames per turn
AXIS_X = 607               # column the bust turns around (centre of the front and back views)
CUT_Y = 668                # shared baseline: just above the bust's rounded underside
PAD = 12                   # margin above her hair / beside her, px
SMALL = 0.7                # phone frame scale
FLOW_MAX = 16.0            # px of motion that maps to the ends of the 8-bit flow range
FLOW_DOWN = 3              # flow maps are stored at 1/3 size

cap = cv2.VideoCapture(SRC)
video = []
while True:
    ok, f = cap.read()
    if not ok:
        break
    video.append(cv2.cvtColor(f, cv2.COLOR_BGR2RGB))
frames = video[START:START + PERIOD]
H, W = frames[0].shape[:2]


def matte(rgb8):
    """Soft alpha for the subject: the biggest thing that differs from the background."""
    rgb = rgb8.astype(np.float32)
    border = np.concatenate([rgb[:30].reshape(-1, 3), rgb[:, :30].reshape(-1, 3), rgb[:, -30:].reshape(-1, 3)])
    bg = np.median(border, axis=0)
    dist = np.sqrt(((rgb - bg) ** 2).sum(axis=2))
    lab, n = ndi.label(dist > 24)
    sizes = ndi.sum(dist > 24, lab, range(1, n + 1))
    mask = ndi.binary_fill_holes(lab == int(np.argmax(sizes)) + 1)  # drops the corner watermark
    inner = ndi.binary_erosion(mask, iterations=2)
    outer = ndi.binary_dilation(mask, iterations=2)
    dmax = ndi.maximum_filter(np.where(mask, dist, 0), size=9)
    band = np.clip((dist - 10) / np.maximum(dmax - 10, 1), 0, 1)
    alpha = np.where(inner, 1.0, np.where(outer, band, 0.0))
    # take the background colour back out of the semi-transparent edge, then bleed
    # subject colour outward so texture filtering never pulls background in
    al = np.clip(alpha, 0.2, 1)[..., None]
    col = np.where((alpha < 0.999)[..., None], np.clip((rgb - (1 - al) * bg) / al, 0, 255), rgb)
    solid = alpha > 0.6
    idx = ndi.distance_transform_edt(~solid, return_distances=False, return_indices=True)
    col = np.where(solid[..., None], col, col[idx[0], idx[1]])
    return col, alpha, mask


mattes = [matte(f) for f in frames]
x_lo = min(np.where(m[2].any(axis=0))[0].min() for m in mattes)
x_hi = max(np.where(m[2].any(axis=0))[0].max() for m in mattes)
top = min(np.where(m[2].any(axis=1))[0].min() for m in mattes) - PAD
half = max(AXIS_X - x_lo, x_hi - AXIS_X) + PAD
x0, x1, y0, y1 = AXIS_X - half, AXIS_X + half, top, CUT_Y
cw, ch = x1 - x0, y1 - y0
print(f'loop {START}..{START + PERIOD - 1}  crop x {x0}-{x1} y {y0}-{y1}  frame {cw}x{ch}')

# angles: the turn eases, so pace it by picture change (smoothed around the loop)
small = [cv2.cvtColor(cv2.resize(f, (160, 90)), cv2.COLOR_RGB2GRAY).astype(np.float32) for f in frames]
change = np.array([np.abs(small[(i + 1) % PERIOD] - small[i]).mean() for i in range(PERIOD)])
change = ndi.uniform_filter1d(change, 5, mode='wrap')
yaw = np.concatenate([[0], np.cumsum(change)[:-1]]) / change.sum() * 360

for f in glob.glob(f'{OUT}/*'):
    os.remove(f)

crops = []
for i, (col, alpha, mask) in enumerate(mattes):
    a = alpha[y0:y1, x0:x1].copy()
    a[-1:] = mask[y1 - 1:y1, x0:x1]  # baseline stays a clean straight edge
    rgba = np.dstack([col[y0:y1, x0:x1], a * 255]).astype(np.uint8)
    img = Image.fromarray(rgba)
    img.save(f'{OUT}/t{i:03d}.webp', 'WEBP', quality=90, method=6, exact=True)
    img.resize((round(cw * SMALL), round(ch * SMALL)), Image.LANCZOS).save(f'{OUT}/s{i:03d}.webp', 'WEBP', quality=88, method=6, exact=True)
    crops.append((cv2.cvtColor(frames[i][y0:y1, x0:x1], cv2.COLOR_RGB2GRAY), mask[y0:y1, x0:x1]))

dis = cv2.DISOpticalFlow_create(cv2.DISOPTICAL_FLOW_PRESET_MEDIUM)
peak = 0.0
for i in range(PERIOD):
    (ga, ma), (gb, mb) = crops[i], crops[(i + 1) % PERIOD]
    flow = dis.calc(ga, gb, None)
    # keep motion only where she is (either frame), smoothed without pulling in the empty background
    m = ndi.binary_dilation(ma | mb, iterations=4).astype(np.float32)
    wgt = cv2.GaussianBlur(m, (0, 0), 3)
    flow = np.dstack([cv2.GaussianBlur(flow[..., k] * m, (0, 0), 3) / np.maximum(wgt, 1e-3) for k in (0, 1)])
    flow *= (wgt > 0.02)[..., None]
    peak = max(peak, float(np.abs(flow).max()))
    lo = cv2.resize(flow, (round(cw / FLOW_DOWN), round(ch / FLOW_DOWN)), interpolation=cv2.INTER_AREA)
    enc = np.clip(lo / FLOW_MAX, -1, 1) * 127 + 128
    out = np.dstack([enc[..., 0], enc[..., 1], np.full(enc.shape[:2], 128)]).round().astype(np.uint8)
    Image.fromarray(out).save(f'{OUT}/f{i:03d}.png', optimize=True)
print(f'peak motion between neighbours: {peak:.1f}px (range ±{FLOW_MAX}px)')

json.dump({
    'width': int(cw), 'height': int(ch), 'flowMax': FLOW_MAX,
    'frames': [{'name': f'{i:03d}', 'yaw': round(float(y), 2)} for i, y in enumerate(yaw)],
}, open(MANIFEST, 'w'), indent=1)
print(PERIOD, 'frames written; yaw every 10th:', [round(float(y)) for y in yaw[::10]])

import { Suspense, useEffect, useRef } from 'react'
import Lenis from 'lenis'
import { Canvas } from '@react-three/fiber'
import { motion, useScroll, useTransform, type MotionValue } from 'framer-motion'
import * as THREE from 'three'
import Scene from './scene/Scene'
import Nav from './ui/Nav'
import Resume from './ui/Resume'
import Works from './ui/Works'
import Contact from './ui/Contact'
import LoadingScreen from './ui/LoadingScreen'
import { RESUME_PDF } from './data/resume'
import { scrollToNav } from './ui/scrollTo'

// First-screen copy.
const COPY = {
  title: 'Riya Gandhi',
  role: 'Brand Strategist',
  paragraphs: [
    "I build brands people choose to spend time with. Positioning, messaging and creative direction, grounded in what audiences actually do, not what we hope they'll do. At a healthcare brand, that thinking grew a YouTube presence to 60M+ views and shaped how the brand showed up across ads, creators and content.",
    "Now taking that same audience-first rigour to brand strategy end to end: who we are, who we're for, and why it should matter to them.",
  ],
  workCta: 'See the Work',
  resumeCta: 'Download résumé (PDF)',
  scrollCue: 'Scroll to explore',
  // corner metadata of the decorative frame
  edition: 'Portfolio, Edition 2026',
  credo: 'Journalism-trained · Audience-led',
  path: 'Est. in the newsroom · Brand strategy',
}

const viewportHeight = () => window.innerHeight || 800

// First screen. The copy sits in the same right-hand column as the rail, so the
// character has the left of the screen to herself from the very first frame.
function Hero({ scrollY, cueOpacity }: { scrollY: MotionValue<number>; cueOpacity: MotionValue<number> }) {
  // The copy dissolves over the first ~40% of a screen of scroll: fade + blur, with a
  // little parallax (title rises faster and its tracking opens up, body rises slower).
  // (viewport height is read live, so a resize never leaves the range stale)
  const p = useTransform(scrollY, (y) => Math.min(1, Math.max(0, y / (viewportHeight() * 0.4))))
  const opacity = useTransform(p, [0, 0.8], [1, 0])
  const titleY = useTransform(p, [0, 1], [0, -72])
  const bodyY = useTransform(p, [0, 1], [0, -40])
  // faded-out buttons must not catch clicks
  const actionEvents = useTransform(opacity, (v) => (v < 0.1 ? 'none' : 'auto'))
  return (
    <section className="hero">
      <div className="hero-col">
        <motion.div className="about" style={{ opacity }}>
          {/* entrance animation sits on the inner wrapper so its fill doesn't lock the
              scroll-driven opacity on the outer one */}
          <div className="about-intro">
            <motion.p className="about-role" style={{ y: bodyY }}>
              {COPY.role}
            </motion.p>
            <motion.h1 className="about-title" style={{ y: titleY }}>
              {COPY.title}
            </motion.h1>
            {COPY.paragraphs.map((text, i) => (
              <motion.p key={i} className="about-body" style={{ y: bodyY }}>
                {text}
              </motion.p>
            ))}
            <motion.div className="about-actions" style={{ y: bodyY, pointerEvents: actionEvents }}>
              <button className="btn is-solid" onClick={() => scrollToNav('work')}>
                {COPY.workCta}
              </button>
              <a className="btn" href={RESUME_PDF.href} download={RESUME_PDF.filename}>
                {COPY.resumeCta}
              </a>
            </motion.div>
          </div>
        </motion.div>
        <motion.div className="scroll-cue" style={{ opacity: cueOpacity }} aria-hidden="true">
          <span className="scroll-cue-track">
            <span className="scroll-cue-dot" />
          </span>
          <span className="scroll-cue-label">{COPY.scrollCue}</span>
        </motion.div>
      </div>
    </section>
  )
}

export default function App() {
  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.1,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      wheelMultiplier: 1.0,
      touchMultiplier: 1.5,
    })

    let rafId: number
    function raf(time: number) {
      lenis.raf(time)
      rafId = requestAnimationFrame(raf)
    }

    rafId = requestAnimationFrame(raf)

    return () => {
      cancelAnimationFrame(rafId)
      lenis.destroy()
    }
  }, [])

  const { scrollY } = useScroll()
  // Works veil: as the gallery's top travels from the bottom of the viewport to its
  // middle, the 3D scene behind it dims…
  const worksRef = useRef(null)
  const { scrollYProgress: worksProgress } = useScroll({
    target: worksRef,
    offset: ['start end', 'start center'],
  })
  // …and lifts most of the way again as the last screen (contact) scrolls in.
  const contactRef = useRef(null)
  const { scrollYProgress: contactProgress } = useScroll({
    target: contactRef,
    offset: ['start end', 'end end'],
  })
  const fogBg = useTransform(
    [worksProgress, contactProgress],
    ([w, c]: number[]) => `rgba(8, 11, 18, ${(0.62 * w * (1 - 0.85 * c)).toFixed(3)})`
  )
  // The text column's backing (right-side scrim + frosted glass) is there from the
  // first screen, steps aside while the gallery covers the column (gallery top
  // travelling from mid-viewport to the top), and returns for the contact screen.
  const { scrollYProgress: railOut } = useScroll({
    target: worksRef,
    offset: ['start center', 'start start'],
  })
  const backing = useTransform([railOut, contactProgress], ([out, c]: number[]) => {
    return Math.min(1, 1 - out + c)
  })
  const scrimOpacity = useTransform(backing, (b) => b * 0.42)
  // first-screen scroll cue / top gradient / decorative frame + inline nav: fade on scroll
  const cueOpacity = useTransform(scrollY, [0, 160], [1, 0])
  const heroGradientOpacity = useTransform(scrollY, [0, 320], [1, 0])
  const heroChromeOpacity = useTransform(scrollY, [0, 280], [1, 0])

  return (
    <>
      {/* Loading mask: covers the screen until every turntable frame is in, then fades */}
      <LoadingScreen />

      {/* Fixed 3D background */}
      <div className="scene-bg">
        <Canvas
          dpr={[1, 1.5]}
          camera={{ position: [3, 0.6, 7], fov: 26, near: 0.1, far: 800 }}
          gl={{ antialias: false, stencil: false, depth: true, toneMapping: THREE.ACESFilmicToneMapping }}
        >
          <color attach="background" args={['#0a0e16']} />
          <Suspense fallback={null}>
            <Scene />
          </Suspense>
        </Canvas>
      </div>

      {/* Phones: dissolves the character's base into the backdrop (hidden on wide layouts) */}
      <div className="base-fade" aria-hidden="true" />

      {/* Right-side scrim behind the text column */}
      <motion.div className="scrim" style={{ opacity: scrimOpacity }} aria-hidden="true" />

      {/* Fixed veil over the scene for the works gallery (dim only) */}
      <motion.div className="stage-fog" style={{ background: fogBg }} aria-hidden="true" />

      {/* Fixed frosted glass behind the text column */}
      <motion.div className="glass-rail" style={{ opacity: backing }} aria-hidden="true" />

      {/* First-screen gradients (top band behind the nav; on phones also behind the copy) */}
      <motion.div className="hero-gradient" style={{ opacity: heroGradientOpacity }} aria-hidden="true" />

      {/* First-screen decoration: hairline frame + corner marks + corner metadata */}
      <motion.div className="hero-chrome" style={{ opacity: heroChromeOpacity }} aria-hidden="true">
        <div className="hero-frame" />
        <span className="hero-mark tl">+</span>
        <span className="hero-mark tr">+</span>
        <span className="hero-mark bl">+</span>
        <span className="hero-mark br">+</span>
        <div className="hero-meta hm-tl">
          <span className="hm-name">{COPY.title}</span>
          <span>{COPY.role}</span>
        </div>
        <div className="hero-meta hm-bl">{COPY.credo}</div>
        <div className="hero-meta hm-br">{COPY.edition}</div>
        <div className="hero-meta hm-right">{COPY.path}</div>
      </motion.div>

      <Nav chromeOpacity={heroChromeOpacity} />

      {/* Full-screen film-grain overlay (multiply blend) */}

      {/* Scrolling content */}
      <main className="content">
        <Hero scrollY={scrollY} cueOpacity={cueOpacity} />
        <Resume />
        <Works innerRef={worksRef} />
        <Contact innerRef={contactRef} />
      </main>
    </>
  )
}

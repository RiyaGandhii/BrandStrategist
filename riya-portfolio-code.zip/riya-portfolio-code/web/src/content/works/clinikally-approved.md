---
title: Clinikally Approved. Original brand IP, built from the ground up.
video: prVf3rsIJ7A
role: Conceived, built, and produced by Riya
tags: [Podcast, Episode showcase]
link: https://www.youtube.com/watch?v=prVf3rsIJ7A
linkLabel: Watch on YouTube
---

Clinikally Approved didn't exist before I proposed it. A clinical brand needed a warmer, more human voice, so I built a format that paired a doctor's expertise with a curious, everyday host asking what viewers actually wanted to know. I conceived the format, built the structure, and scripted and produced every episode, working alongside Dr. Sarkar as on-camera talent. It became one of the brand's most trusted ways to talk to its audience.

## Episode showcase

| Episodes | Lifetime views | Watch hours | Top episode views |
| --- | --- | --- | --- |
| 17 | 1.2M+ | 16.5K+ | 495K+ |

One episode alone, "Which Serum to Use?" crossed 495,000 views.

> Concept, format and production originated by Riya Gandhi, produced for Clinikally from launch through 17 episodes. Also hosted and moderated "Uncomplicated: Skincare, Simplified by Dermatologists and AI," the brand's public webinar.

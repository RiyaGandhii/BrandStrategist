---
title: Example work
video: YOUTUBE_VIDEO_ID
banner: /works/example/banner.jpg
year: 2026
role: Strategy / Production
tags: [Example tag, Another tag]
link: https://example.com
linkLabel: Open link
---

> **This is a work-detail template.** Copy it to `src/content/works/<slug>.md`, where
> `<slug>` matches the `slug` of an item in `src/data/works.ts` (or `CHANNEL.slug` in
> `src/data/resume.ts`). That item then opens as a full detail. This file's slug is
> `example`, which no item uses, so it never appears on the site.

## A heading

The body is standard Markdown: **bold**, *italic*, [links](https://example.com), lists:

- Point one
- Point two

and tables:

| Metric | Before | After |
| --- | --- | --- |
| Retention | 42% | 58% |

## Images and video

Put media in `public/works/<slug>/` and reference it with `/works/...` paths:

![Alt text](/works/example/1.jpg)

<video src="/works/example/demo.mp4" autoplay muted loop playsinline></video>

---

Frontmatter fields (all optional):

| Field | What it does |
| --- | --- |
| `title` | Detail title (falls back to the item name in works.ts) |
| `video` | YouTube id — the detail opens with the player (use this *or* `banner`) |
| `banner` | Top banner image path |
| `year` | Year |
| `role` | Credit line under the title |
| `tags` | Tag array, e.g. `[Podcast, YouTube]` |
| `link` | External link, rendered as a button |
| `linkLabel` | That button's text |

---
title: Where the numbers come from.
role: Inside the channel
tags: [YouTube Studio Analytics, Jun 2025 – Jun 2026]
---

![YouTube Studio analytics — Average percentage viewed by content](/works/inside-the-channel/analytics.jpg)

Period: Jun 2025 – Jun 2026 · Source: YouTube Studio Analytics

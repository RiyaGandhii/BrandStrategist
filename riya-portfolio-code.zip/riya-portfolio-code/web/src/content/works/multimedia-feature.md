---
title: Multimedia feature
video: pDkCQ5U5Kzg
role: Newsroom · Storytelling
tags: [Production, Direction]
link: https://www.youtube.com/watch?v=pDkCQ5U5Kzg
linkLabel: Watch on YouTube
---

Scripted, edited and produced in the newsroom: the discipline of finding the real story and structuring it for how people watch on social.

---
title: Growth without ad spend
video: k7Kds11QFIU
role: Organic growth · YouTube
tags: [Organic growth, YouTube]
link: https://www.youtube.com/watch?v=k7Kds11QFIU
linkLabel: Watch on YouTube
---

Proof the strategy worked without paid support: an organic video that outperformed the channel's typical baseline by nearly 10x on views, earning attention on the strength of the topic and structure alone.

| Result | This video | Versus usual |
| --- | --- | --- |
| Views | 11.2K | +10.1K |
| Watch hours | 234.1 | +214.1 |
| Subscribers | +60 | — |

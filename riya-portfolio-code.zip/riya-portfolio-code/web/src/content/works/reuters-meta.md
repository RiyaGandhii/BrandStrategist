---
title: Introduction to Digital Journalism
role: Reuters · Meta Journalism Project
tags: [Certification]
---

![Reuters / Meta Journalism Project certificate — Introduction to Digital Journalism, awarded to Riya Gandhi](/works/certifications/reuters-meta.jpg)

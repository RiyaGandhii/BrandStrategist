---
title: AI in the Newsroom: The Ethical Approach
role: Thomson Foundation
tags: [Certification]
---

![Thomson Foundation certificate — AI in the Newsroom: The Ethical Approach, awarded to Riya Gandhi](/works/certifications/thomson-foundation.jpg)

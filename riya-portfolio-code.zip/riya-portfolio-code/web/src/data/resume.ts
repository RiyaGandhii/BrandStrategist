// Rail content: everything that scrolls past in the right-hand column, in page order
// (numbers → about → capabilities → framework → career → case study → education).
// Pure data — Resume.tsx only renders it. Images live under public/ and are joined
// with BASE_URL so the build works from any subdirectory.

const asset = (path: string) => `${import.meta.env.BASE_URL}${path}`

export interface Stat {
  value: string
  label: string
}

export interface Brand {
  name: string
  logo: string
  // optical size in the logo grid: 1 = the shared size; wide wordmarks go a little
  // larger, tall or icon-heavy marks a little smaller, so all six read as equal
  scale?: number
}

export interface Capability {
  no: string
  title: string
  body: string
  tags: string[]
}

export interface FrameworkStage {
  no: string
  name: string
  body: string
}

export interface CareerEntry {
  period: string
  place: string
  sector: string
  role: string
  logo?: Brand
  points: string[]
}

export interface CaseSection {
  label: string
  body: string
  points?: string[] // numbered lines shown under the body
}

export interface EducationEntry {
  period: string
  degree: string
  school: string
}

export const RESUME_PDF = {
  href: 'https://drive.google.com/uc?export=download&id=1CMob-omcOcWy6piQJHxo9FbQZGyAxLxY',
  filename: 'Riya-Gandhi-Resume.pdf',
}

const BRANDS: Record<string, Brand> = {
  wion: { name: 'WION', logo: asset('images/brands/wion.png'), scale: 0.85 },
  clinikally: { name: 'Clinikally', logo: asset('images/brands/clinikally.png'), scale: 1.15 },
  inc42: { name: 'Inc42', logo: asset('images/brands/inc42.png'), scale: 0.9 },
  zee: { name: 'Zee Media', logo: asset('images/brands/zee-media.png'), scale: 0.95 },
  coingape: { name: 'CoinGape', logo: asset('images/brands/coingape.png'), scale: 1.1 },
  unifit: { name: 'Unifit Realty', logo: asset('images/brands/unifit.png'), scale: 0.85 },
}

export const NUMBERS = {
  eyebrow: 'By the numbers',
  intro:
    'Twelve months shaping how a healthcare brand showed up on YouTube. The strategy was simple: earn attention instead of buying it. The result was reach that compounded, an audience that stayed, and a channel that started paying for itself.',
  stats: [
    { value: '60.7M+', label: 'Views earned' },
    { value: '14M', label: 'People reached' },
    { value: '80.3%', label: 'Average video watched, attention that held' },
    { value: '58%', label: 'Longform retention, up from 42%' },
    { value: '100K', label: 'Subscribers, an owned audience built from zero' },
    { value: 'YPP', label: 'Channel monetised, turning content cost into revenue' },
  ] as Stat[],
  source: 'Period: Jun 2025 to Jun 2026 · Source: YouTube Studio Analytics',
}

// "Inside the channel": the analytics screenshot. Opens full size via its works doc.
export const CHANNEL = {
  eyebrow: 'Inside the channel',
  title: 'Where the numbers come from.',
  image: asset('works/inside-the-channel/analytics.jpg'),
  alt: 'YouTube Studio analytics — Average percentage viewed by content',
  slug: 'inside-the-channel',
}

export const BRANDS_BLOCK = {
  title: "Brands I've worked with",
  eyebrow: 'Newsrooms · Brands · Platforms',
  note: 'Editorial, video and social work across news, health, fintech and real estate.',
  logos: [BRANDS.wion, BRANDS.clinikally, BRANDS.inc42, BRANDS.zee, BRANDS.coingape, BRANDS.unifit],
}

export const ABOUT = {
  eyebrow: 'About',
  title: 'A journalist who learned to make the algorithm care.',
  paragraphs: [
    "Riya Gandhi is a Brand Strategist who started in the newsroom and never lost the instinct for a story. She helps brands figure out what they stand for, who they're for, and how to say it in a way people actually stop for.",
    'Her foundation is journalism. At WION she scripted, edited and produced multimedia features, and learned the discipline that still drives her strategy work: find the real story, structure it before you style it, and never assume the audience is still listening.',
    'At UniFit she ran community-led social campaigns, her first lesson in building a brand with an audience rather than at one.',
    'Most recently, at a healthcare brand, she shaped how the brand showed up on YouTube, growing it to 60M+ views and turning audience behaviour into a repeatable content playbook that informed positioning, creative and partnerships.',
    "Today she works across brand positioning, messaging, storytelling and audience insight. She pairs editorial instinct with quantitative rigour, so every brief starts with what people actually do, not what we hope they'll do.",
  ],
}

export const CAPABILITIES = {
  title: 'What I do',
  eyebrow: 'Core capabilities',
  items: [
    {
      no: '01',
      title: 'Brand Positioning & Strategy',
      body: "Mapped a healthcare brand's four business lines against 20+ Indian and global competitors, and recommended doubling down on doctor-backed credibility over the crowded skincare-enthusiast space. Built the private-label growth plan and a four-stage omnichannel roadmap connecting clinics, app and products.",
      tags: ['Positioning', 'Competitive Analysis', 'Brand Roadmaps'],
    },
    {
      no: '02',
      title: 'Audience Insight & Content Strategy',
      body: 'Read the data behind the growth. When ad-driven reach started diluting retention, I made the case for fewer, better videos and reset the monthly content model. Built TSYS, a context-first storytelling framework, and grew the channel to 60M+ views with 80.3% average percentage viewed.',
      tags: ['Audience Insight', 'Retention', 'TSYS Framework'],
    },
    {
      no: '03',
      title: 'Brand IP & Storytelling',
      body: "Conceived, scripted and produced an original brand podcast from scratch, taking it to 17 episodes and 1.2M+ views. Wrote the brand film and hosted the brand's public webinar, giving a clinical category a warm, human voice.",
      tags: ['Original IP', 'Brand Film', 'Narrative'],
    },
    {
      no: '04',
      title: 'Creator & Partnership Strategy',
      body: 'Designed creator and doctor partnerships that protect editorial trust, separating education from product talk and building in advertising and health-claim compliance from day one. Planned a 50-video UGC campaign across five formats with one consistent brand face.',
      tags: ['Partnerships', 'Influencer Strategy', 'Compliance'],
    },
    {
      no: '05',
      title: 'Campaigns & Paid Amplification',
      body: 'Ran YouTube campaigns on Google Ads, with top performers "Internet ki Nahi, Dermat ki Suno" (~13.1M views) and "Nuskhon Ka The End" (~24.18M views). Split paid from organic so the brand could see what was truly earning attention.',
      tags: ['Google Ads', 'Campaign Strategy', 'Paid vs Organic'],
    },
    {
      no: '06',
      title: 'Measurement & Commercial Impact',
      body: "Connected content to the business. Built year-on-year analytics, traced YouTube's role in store traffic (sessions up about 3x year on year), and pushed for proper attribution so every brief is judged on outcomes, not vanity metrics.",
      tags: ['Analytics', 'Attribution', 'Commerce'],
    },
  ] as Capability[],
}

export const FRAMEWORK = {
  eyebrow: 'The framework',
  title: 'A brand operating system',
  intro:
    'The repeatable way I build brands. Seven stages, run as one continuous loop, so every cycle makes the brand sharper, clearer and harder to copy.',
  stages: [
    { no: '01', name: 'Insight', body: 'Who the audience really is, what they search for, what they believe, and where competitors leave a gap.' },
    { no: '02', name: 'Position', body: 'The one space the brand can own, and the structural reasons it can win there, beyond aesthetics.' },
    { no: '03', name: 'Message', body: 'The story, voice and proof points that make the position believable: what we say, and what we never say.' },
    { no: '04', name: 'Express', body: 'Turning strategy into work people stop for: brand films, original IP, content series and creative briefs, built on context-first storytelling (TSYS).' },
    { no: '05', name: 'Amplify', body: 'Getting it in front of the right people: creator and doctor partnerships, paid campaigns, and cross-platform distribution, with compliance built in.' },
    { no: '06', name: 'Measure', body: 'Separating paid from organic, tracking attention that holds, and tying content to business outcomes like store traffic and conversion.' },
    { no: '07', name: 'Evolve', body: 'Feeding what the audience taught us back into the positioning, not just the next post.' },
  ] as FrameworkStage[],
  loop: {
    title: 'Back to 01. The loop never resets.',
    body: 'Each pass sharpens the next: clearer positioning, stronger trust, compounding reach. Content is how the brand speaks; strategy decides what it says. That is where the growth comes from.',
  },
}

export const CAREER = {
  title: 'Career so far',
  eyebrow: '4+ years · Five newsrooms & brands',
  intro:
    "The through line: a journalist's instinct for what audiences actually care about, applied first to stories, then to brands.",
  entries: [
    {
      period: 'Feb 2025 to Sep 2026',
      place: 'Clinikally',
      sector: 'Telehealth & Dermatology',
      role: 'Brand Content Strategist & YouTube Manager',
      logo: BRANDS.clinikally,
      points: [
        'Shaped brand positioning across four business lines, recommending a doctor-backed strategy over the crowded skincare-enthusiast space, with a private-label growth plan and omnichannel roadmap.',
        "Built the brand's YouTube into a 60M+ view channel and unlocked Partner Program monetisation, resetting the content model when data showed ad-driven reach was diluting retention.",
        "Created original brand IP: conceived and produced the brand podcast (17 episodes, 1.2M+ views), wrote the brand film, and hosted the brand's public webinar.",
        'Led creator and doctor partnerships, paid campaigns and attribution, tying content to store traffic and conversion.',
      ],
    },
    {
      period: 'Sep 2024 to Dec 2024',
      place: 'Inc42',
      sector: 'Startup Media',
      role: 'Video Producer',
      logo: BRANDS.inc42,
      points: [
        "Produced branded and founder-led video for India's leading startup media platform across healthtech, fintech and AI.",
        'Researched and scripted branded content for high-growth startups through BrandLabs, translating complex businesses into stories audiences followed.',
        'Led on-ground video at major startup ecosystem events, including founder interviews and live coverage.',
      ],
    },
    {
      period: 'Jan 2024 to Jun 2024',
      place: 'CoinGape Media',
      sector: 'Crypto & Tech',
      role: 'Video Journalist',
      logo: BRANDS.coingape,
      points: [
        'Grew Instagram reach 38% with an audience-first content strategy built on clarity and consistency.',
        'Made crypto and Web3 accessible to a fast-growing audience through SEO-driven explainer and news video.',
        'Built a repeatable daily publishing system under tight news deadlines.',
      ],
    },
    {
      period: 'Jun 2023 to Dec 2023',
      place: 'WION',
      sector: 'Zee Media',
      role: 'Digital Journalist',
      logo: BRANDS.wion,
      points: [
        'Produced viral digital content for a 10.5M-subscriber channel, with individual videos reaching 1.6M+ views.',
        'Adapted broadcast news into digital-first formats optimised for YouTube and social.',
        'Managed publishing workflows, metadata optimisation and audience performance tracking.',
      ],
    },
    {
      period: 'Dec 2020 to Mar 2022',
      place: 'UniFit India',
      sector: 'Real Estate',
      role: 'Social Media Executive',
      logo: BRANDS.unifit,
      points: [
        'Planned and ran community-led content campaigns across social platforms for a real estate brand.',
        'Used engagement and performance data to refine messaging and drive steady audience growth.',
      ],
    },
  ] as CareerEntry[],
}

export const CASE_STUDY = {
  eyebrow: 'Featured case study',
  title: 'Positioning a healthcare brand: doctor-backed over trend-led',
  intro:
    'A brand strategy for a telehealth dermatology platform whose own product range was being outsold by the third-party brands it sold alongside.',
  sections: [
    {
      label: 'The problem',
      body: 'The brand had real doctors, consultation infrastructure and an AI skin-analysis tool, yet customers were choosing other labels on its own marketplace. The pull was toward repositioning as a trend-led skincare brand, competing on aesthetics and influencer buzz.',
    },
    {
      label: 'The insight',
      body: 'That space was crowded with better-funded players. The real gap was doctor-backed credibility, and the brand already owned the hardest parts to copy: doctors, diagnostics, patent-protected formulations and regulatory trust. Warmth was an execution problem, not a positioning one.',
    },
    {
      label: 'The strategy',
      body: 'Three workstreams:',
      points: [
        'Positioning: double down on doctor-backed credibility rather than pivot to the enthusiast market.',
        'Private-label growth: a 20+ idea plan across packaging, pricing, regimen bundles, subscriptions and a doctor-led content engine, rolled out over 12 months.',
        'Omnichannel: a four-stage roadmap turning offline experience centres into diagnostic entry points connected to the app and products.',
      ],
    },
    {
      label: 'The execution',
      body: "Mapped four business lines against 20+ Indian and global competitors, defined the consult-to-product funnel as the highest-leverage opportunity, and set north-star metrics: consult-to-product attach rate, repeat purchase rate, and the product range's share of sales.",
    },
  ] as CaseSection[],
  insight: {
    label: 'Key insight',
    body: 'Structural advantages beat aesthetics. A brand that owns its doctors and diagnostics should make that the story, then make it feel warm.',
  },
  // the secondary case, shown smaller under the featured one
  craft: {
    eyebrow: 'Craft case study',
    title: 'TSYS: fixing where viewers left',
    body: "Longform videos were losing viewers around the 50-second mark. They opened with a hook but delayed the reason to care. I built TSYS (Tell, Show, Yield, Summarize), a context-first structure that tells viewers why it matters before the visual payoff, using short teasers to front-load relevance. It became the scripting standard for the channel's longform videos.",
  },
}

export const EDUCATION = {
  title: 'Education',
  eyebrow: 'Foundations',
  entries: [
    {
      period: '2022 — 2023',
      degree: 'PG Diploma in Multimedia Journalism',
      school: 'Asian College of Journalism',
    },
    {
      period: '2017 — 2020',
      degree: 'BBA, Bachelor of Business Administration',
      school: 'The NorthCap University',
    },
  ] as EducationEntry[],
}

// Work detail content: one markdown file per work, in src/content/works/<slug>.md
//
// frontmatter fields (between the --- lines, all optional):
//   title      title (falls back to the item name in works.ts)
//   video      YouTube id — the detail opens with the player instead of a banner
//   banner     top banner image path (e.g. /works/<slug>/banner.jpg)
//   year       year
//   role       role / credit line
//   tags       tag array: [Podcast, Episode showcase]
//   link       external link (button under the body)
//   linkLabel  that button's text (default: WORKS.visitLabel)
// Body (after the frontmatter) is markdown: text / images ![](...) / tables /
// raw html such as <video src=...>.
//
// Media goes in public/works/<slug>/ and is referenced with /works/... paths
// (Works.tsx rewrites them against BASE_URL so subdirectory deploys keep working).
// A list item (works.ts) is linked to its md by `slug`.

export interface WorkDoc {
  slug: string
  title?: string
  video?: string
  banner?: string
  year?: string
  role?: string
  tags?: string[]
  link?: string
  linkLabel?: string
  body: string
}

// 构建期把全部 md 作为原始字符串内联进来
const files = import.meta.glob('../content/works/*.md', {
  query: '?raw',
  import: 'default',
  eager: true,
}) as Record<string, string>

// 极简 frontmatter 解析（key: value，数组用 [a, b]）——避免引入依赖 Buffer 的库
function parseFrontmatter(raw: string): {
  data: Record<string, string | string[]>
  body: string
} {
  const m = /^---\s*\n([\s\S]*?)\n---\s*\n?([\s\S]*)$/.exec(raw)
  if (!m) return { data: {}, body: raw }
  const data: Record<string, string | string[]> = {}
  for (const line of m[1].split('\n')) {
    const mm = /^([A-Za-z0-9_-]+)\s*:\s*(.*)$/.exec(line.trim())
    if (!mm) continue
    const rawVal = mm[2].trim()
    let val: string | string[]
    if (rawVal.startsWith('[') && rawVal.endsWith(']')) {
      val = rawVal
        .slice(1, -1)
        .split(',')
        .map((s) => s.trim().replace(/^['"]|['"]$/g, ''))
        .filter(Boolean)
    } else {
      val = rawVal.replace(/^['"]|['"]$/g, '')
    }
    data[mm[1]] = val
  }
  return { data, body: m[2].trim() }
}

const docs: Record<string, WorkDoc> = {}
for (const path in files) {
  const slug = path.split('/').pop()!.replace(/\.md$/, '')
  const { data, body } = parseFrontmatter(files[path])
  docs[slug] = { slug, ...data, body } as WorkDoc
}

export function getWorkDoc(slug?: string): WorkDoc | null {
  return slug ? docs[slug] || null : null
}

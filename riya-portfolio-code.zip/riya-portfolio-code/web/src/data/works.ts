// Works gallery data: the horizontal cards after the rail (podcast → selected work →
// in print → certifications). Pure data — add / remove sections and items here only;
// Works.tsx just renders it.
//
// Section fields:
//   id        unique id (also the nav target, see ui/Nav.tsx)
//   no        index label '01'…
//   kicker    small line above the title (optional)
//   title     card title
//   tagline   one line under the title
//   layout    how the items are drawn:
//               'feature'  lede + stats on the left, one big video + notes on the right
//               'media'    rows with a video thumbnail
//               'list'     numbered text rows (external links)
//               'tiles'    image tiles side by side
//   lede / stats / notes   extra copy for the 'feature' layout (optional)
//   items[]   { name, label?, desc?, meta?, tags?, slug?, link?, video?, image? }
//               slug   opens the full-screen detail rendered from content/works/<slug>.md
//               link   external URL — an item with a link and no slug opens it directly
//               video  YouTube id (thumbnail on the card)
//               image  thumbnail path under public/

const asset = (path: string) => `${import.meta.env.BASE_URL}${path}`

export interface WorkListItem {
  name: string
  label?: string
  desc?: string
  meta?: string
  tags?: string[]
  link?: string
  slug?: string
  video?: string
  image?: string
}

export interface WorkStat {
  value: string
  label: string
}

export interface WorkSection {
  id: string
  no: string
  kicker?: string
  title: string
  tagline: string
  layout: 'feature' | 'media' | 'list' | 'tiles'
  lede?: string
  stats?: WorkStat[]
  notes?: string[]
  items: WorkListItem[]
}

export interface WorksData {
  title: string
  closeLabel: string
  hint: string
  visitLabel: string
  playLabel: string
  viewLabel: string
  sections: WorkSection[]
}

export const youtubeThumb = (id: string) => `https://i.ytimg.com/vi/${id}/maxresdefault.jpg`

export const WORKS: WorksData = {
  title: 'Work',
  closeLabel: 'Back',
  hint: 'Keep scrolling',
  visitLabel: 'Open link',
  playLabel: 'Play',
  viewLabel: 'View',
  sections: [
    {
      id: 'podcast',
      no: '01',
      kicker: 'Podcast · Conceived, built, and produced by Riya',
      title: 'Clinikally Approved.',
      tagline: 'Original brand IP, built from the ground up.',
      layout: 'feature',
      lede: "Clinikally Approved didn't exist before I proposed it. A clinical brand needed a warmer, more human voice, so I built a format that paired a doctor's expertise with a curious, everyday host asking what viewers actually wanted to know. I conceived the format, built the structure, and scripted and produced every episode, working alongside Dr. Sarkar as on-camera talent. It became one of the brand's most trusted ways to talk to its audience.",
      stats: [
        { value: '17', label: 'Episodes' },
        { value: '1.2M+', label: 'Lifetime views' },
        { value: '16.5K+', label: 'Watch hours' },
        { value: '495K+', label: 'Top episode views' },
      ],
      notes: [
        'One episode alone, "Which Serum to Use?" crossed 495,000 views.',
        `Concept, format and production originated by Riya Gandhi, produced for Clinikally from launch through 17 episodes. Also hosted and moderated "Uncomplicated: Skincare, Simplified by Dermatologists and AI," the brand's public webinar.`,
      ],
      items: [
        {
          name: 'Clinikally Approved: episode showcase',
          label: 'Episode showcase',
          slug: 'clinikally-approved',
          video: 'prVf3rsIJ7A',
        },
      ],
    },
    {
      id: 'work',
      no: '02',
      title: 'Selected work',
      tagline: 'Strategy, storytelling & production',
      layout: 'media',
      items: [
        {
          name: 'Doctor-led longform',
          label: 'Brand content · YouTube',
          desc: "Part of the doctor-led content engine behind the brand's positioning: credible, plain-language expertise, structured context-first so viewers know why it matters before the payoff.",
          slug: 'featured-longform',
          video: 'vxxT-qcdFUk',
        },
        {
          name: 'Multimedia feature',
          label: 'Newsroom · Storytelling',
          desc: 'Scripted, edited and produced in the newsroom: the discipline of finding the real story and structuring it for how people watch on social.',
          slug: 'multimedia-feature',
          video: 'pDkCQ5U5Kzg',
        },
        {
          name: 'Growth without ad spend',
          label: 'Organic growth · YouTube',
          desc: "Proof the strategy worked without paid support: an organic video that outperformed the channel's typical baseline by nearly 10x on views, earning attention on the strength of the topic and structure alone.",
          slug: 'organic-growth',
          video: 'k7Kds11QFIU',
        },
      ],
    },
    {
      id: 'writing',
      no: '03',
      title: 'In print',
      tagline: 'Features',
      layout: 'list',
      items: [
        {
          name: 'How Medyseva is solving the doctor drought in rural India with a phygital telemedicine model',
          meta: 'Inc42',
          link: 'https://inc42.com/startups/how-medyseva-is-solving-the-doctor-drought-in-rural-india-with-a-phygital-telemedicine-model/',
        },
        {
          name: 'How startups & enterprises harness AI-powered data insights to drive business growth',
          meta: 'Inc42',
          link: 'https://inc42.com/buzz/how-startups-enterprises-harness-ai-powered-data-insights-to-drive-business-growth/',
        },
        {
          name: 'AI on trading floors: Can AlgoBulls make automated trading mainstream in India?',
          meta: 'Inc42',
          link: 'https://inc42.com/startups/ai-on-trading-floors-can-algobulls-make-automated-trading-mainstream-in-india/',
        },
      ],
    },
    {
      id: 'certs',
      no: '04',
      title: 'Certifications',
      tagline: 'Credentials',
      layout: 'tiles',
      items: [
        {
          name: 'AI in the Newsroom: The Ethical Approach',
          label: 'Thomson Foundation',
          slug: 'thomson-foundation',
          image: asset('works/certifications/thomson-foundation.jpg'),
        },
        {
          name: 'Introduction to Digital Journalism',
          label: 'Reuters · Meta Journalism Project',
          slug: 'reuters-meta',
          image: asset('works/certifications/reuters-meta.jpg'),
        },
      ],
    },
  ],
}

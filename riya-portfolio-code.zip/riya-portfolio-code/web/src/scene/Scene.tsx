import { Suspense, useEffect, useMemo, useRef, type MutableRefObject } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { useTexture } from '@react-three/drei'
import { EffectComposer, Bloom, DepthOfField, SMAA } from '@react-three/postprocessing'
import * as THREE from 'three'
import turntable from '../data/turntable.json'

// Turntable: ONE subject, turning on the spot through a full 360°, in a single slot.
// src/data/turntable.json lists the frames of one complete turn in order, with the
// angle each shows (yaw in degrees: 0 = facing the camera, growing as she turns toward
// screen-left: front → left profile → back → right profile → front).
//
// Per frame, in public/character/ (all generated from a turntable video by
// scripts/prepare-character.py — real footage, nothing mirrored):
//   t###.webp  the cut-out frame        s###.webp  the same, smaller, for phones
//   f###.png   optical flow to the next frame: how each part of her moves between the
//              two. The shader uses it to slide one frame into the next, so the turn
//              is continuous at any speed instead of stepping frame to frame.
const wrap360 = (a: number) => ((a % 360) + 360) % 360
const wrap180 = (a: number) => wrap360(a + 180) - 180 // signed, −180…180
const prefersReducedMotion = () =>
  typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches

const FRAMES = turntable.frames as { name: string; yaw: number }[]
const N = FRAMES.length
const isNarrow = typeof window !== 'undefined' && window.innerWidth <= 640
const BASE = `${import.meta.env.BASE_URL}character/`
const MAP_URLS = FRAMES.map((f) => `${BASE}${isNarrow ? 's' : 't'}${f.name}.webp`)
const FLOW_URLS = FRAMES.map((f) => `${BASE}f${f.name}.png`)
// Everything is fetched before the scene mounts (the loading mask won't lift until then).
const ALL_URLS = [...MAP_URLS, ...FLOW_URLS]
useTexture.preload(ALL_URLS)

// The subject in world units, centred on the origin (base at y = −height / 2).
//   height  world height of a frame
//   faceY   height of the face above the centre: autofocus + parallax pivot
const subject = { height: 3, faceY: 0.8 }

// Same breakpoint as the phone rules in styles.css.
const NARROW = 640

// Plays two neighbouring frames as one: each is shifted along the flow toward the
// in-between moment (frame A forward by t, frame B back by 1 − t), then mixed. The two
// line up, so there is no double image — at t = 0 it is exactly frame A.
const turnVertex = /* glsl */ `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`
const turnFragment = /* glsl */ `
  uniform sampler2D uA;
  uniform sampler2D uB;
  uniform sampler2D uFlow;
  uniform float uT;
  uniform vec2 uFlowUv; // flow range in uv units (y negated: image rows run downward)
  varying vec2 vUv;
  void main() {
    vec2 f = (texture2D(uFlow, vUv).rg * 255.0 - 128.0) / 127.0 * uFlowUv;
    vec4 a = texture2D(uA, vUv - uT * f);
    vec4 b = texture2D(uB, vUv + (1.0 - uT) * f);
    vec4 c = mix(a, b, uT);
    if (c.a < 0.02) discard; // clear pixels don't write depth (keeps depth-of-field honest)
    gl_FragColor = c;
    #include <colorspace_fragment>
  }
`

// Dev-only debugging hook, for checking a frame or tuning the hand-overs from the
// console: __turntable.hold(65) parks her at that yaw, __turntable.release() lets go.
declare global {
  interface Window {
    __turntable?: { hold: (yaw: number) => void; release: () => void }
  }
}

// State the subject publishes each frame for the other scene parts to read.
interface StageState {
  focus: THREE.Vector3 // world point the camera frames and focuses on (her face)
  dist: number // camera distance to it
  mouse: { x: number; y: number } // eased pointer, −1…1
  still: boolean // prefers-reduced-motion: no turning, no floating
}

// Top-to-bottom gradient backdrop (a sphere around the camera); both colours tunable.
function GradientBackground() {
  // The camera's field of view is narrow, so only a thin band of the sphere is on
  // screen; `steep` stretches that band into the full transition.
  // (styles.css --scene-bg should match `bottom`: phones fade her base into it)
  const top = '#a3b09c'
  const bottom = '#a3b09c'
  const steep = 3.2

  const ref = useRef<any>(null)
  const uniforms = useMemo(
    () => ({
      uTop: { value: new THREE.Color() },
      uBottom: { value: new THREE.Color() },
      uSteep: { value: 1 },
    }),
    []
  )
  uniforms.uTop.value.set(top)
  uniforms.uBottom.value.set(bottom)
  uniforms.uSteep.value = steep

  // Follow the camera so the gradient stays put on screen.
  useFrame(({ camera }) => {
    if (ref.current) ref.current.position.copy(camera.position)
  })

  return (
    <mesh ref={ref} scale={300}>
      <sphereGeometry args={[1, 32, 32]} />
      <shaderMaterial
        side={THREE.BackSide}
        depthWrite={false}
        uniforms={uniforms}
        vertexShader={/* glsl */ `
          varying vec3 vDir;
          void main() {
            vDir = normalize(position);
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }
        `}
        fragmentShader={/* glsl */ `
          uniform vec3 uTop;
          uniform vec3 uBottom;
          uniform float uSteep;
          varying vec3 vDir;
          void main() {
            float t = clamp(vDir.y * uSteep * 0.5 + 0.5, 0.0, 1.0);
            gl_FragColor = vec4(mix(uBottom, uTop, t), 1.0);
          }
        `}
      />
    </mesh>
  )
}

// The subject: one mesh that plays the frames as an image sequence. The current yaw
// picks the frame taken nearest to it; there is never more than one frame on screen
// and no fade between two.
//
// Also owns the camera: the subject sits in a fixed slot on screen (left on wide
// layouts, centred on phones) with her base running off the bottom edge, so the body
// is never cropped mid-air or covered by a close-up.
function Subject({ stage }: { stage: MutableRefObject<StageState> }) {
  // Turning.
  //   auto            'off' = she only turns when the page scrolls; 'loop' = keep turning the full 360°; 'pingpong' = sweep `range`
  //                   back and forth (use that when the frames don't go all the way round)
  //   drag            true = a sideways drag on her also turns her
  //   secondsPerTurn  auto speed: time for 360°
  //   range           pingpong sweep (signed yaw)
  //   easeZone        pingpong: degrees before each end over which it slows to a stop
  //   resumeAfter     seconds without a drag / scroll before auto-turn takes over again
  //   rampUp          seconds auto-turn takes to get back up to speed
  //   dragDegPerPx    drag sensitivity
  //   scrollDegPerPx  page-scroll sensitivity
  //   maxScrollStep   cap on scroll-driven turning, degrees per rendered frame
  //   manualEase      drag / scroll smoothing: fraction of the gap left after one second
  //   settleAfter     seconds of stillness before she eases onto the nearest real frame
  //   settleTime      seconds that ease takes (at rest she always shows an untouched frame)
  const turn = {
    auto: 'off' as 'off' | 'loop' | 'pingpong',
    drag: false,
    secondsPerTurn: 16,
    range: [-100, 0] as [number, number],
    easeZone: 30,
    resumeAfter: 1.8,
    rampUp: 1.2,
    dragDegPerPx: 0.45,
    scrollDegPerPx: 0.12,
    maxScrollStep: 8,
    manualEase: 0.001,
    settleAfter: 0.12,
    settleTime: 0.4,
  }
  // Idle float (small enough to stay inside the base's overshoot past the bottom edge).
  const bob = { amp: 0.018, speed: 0.55 }
  // Where the subject sits on screen, as shares of the viewport (0 = left / top edge,
  // 1 = right / bottom edge).
  //   cx        horizontal centre of the slot
  //   top       where the top of her hair sits
  //   bottom    where her base sits. Wide: past the bottom edge, so the body simply runs
  //             off screen. Phones: the copy needs the lower screen, so she sits in the
  //             upper part and .base-fade (styles.css) dissolves her base into the backdrop.
  //   maxWidth  wide layout: most of the viewport width she may take (keeps clear of the text column)
  //   parallax  degrees the camera orbits her face as the mouse moves
  const slot = {
    fov: 26,
    wide: { cx: 0.265, top: 0.1, bottom: 1.04 },
    narrow: { cx: 0.5, top: 0.13, bottom: 0.72 },
    maxWidth: 0.42,
    parallax: 3,
    parallaxEase: 0.1,
  }

  const gl = useThree((s) => s.gl)
  // one request list (same as the preload above), so the loading mask covers all of it
  const loaded = useTexture(ALL_URLS) as THREE.Texture[]
  const maps = useMemo(() => loaded.slice(0, N), [loaded])
  const flows = useMemo(() => loaded.slice(N), [loaded])

  const aspect0 = turntable.width / turntable.height // all frames share one size
  const width = subject.height * aspect0

  // Push every frame to the GPU up front: the first pass must not hitch or flash.
  useMemo(() => {
    maps.forEach((m) => {
      m.colorSpace = THREE.SRGBColorSpace
      m.generateMipmaps = false
      m.minFilter = THREE.LinearFilter
      m.magFilter = THREE.LinearFilter
      m.needsUpdate = true
    })
    flows.forEach((f) => {
      f.colorSpace = THREE.NoColorSpace // data, not colour
      f.generateMipmaps = false
      f.minFilter = THREE.LinearFilter
      f.magFilter = THREE.LinearFilter
      f.needsUpdate = true
    })
  }, [maps, flows])
  useEffect(() => {
    maps.forEach((m) => gl.initTexture(m))
    flows.forEach((f) => gl.initTexture(f))
  }, [gl, maps, flows])

  const uniforms = useMemo(
    () => ({
      uA: { value: maps[0] },
      uB: { value: maps[1 % N] },
      uFlow: { value: flows[0] },
      uT: { value: 0 },
      uFlowUv: { value: new THREE.Vector2(turntable.flowMax / turntable.width, -turntable.flowMax / turntable.height) },
    }),
    [maps, flows]
  )

  // Scroll position and scrollable distance are cached from events: reading them in the
  // render loop would force a layout pass every frame.
  const maxScroll = useRef(1)
  const scrollTop = useRef(0)
  useEffect(() => {
    const measure = () => {
      maxScroll.current = Math.max(1, document.documentElement.scrollHeight - window.innerHeight)
      scrollTop.current = window.scrollY
    }
    measure()
    window.addEventListener('resize', measure)
    const ro = new ResizeObserver(measure)
    ro.observe(document.body)
    return () => {
      window.removeEventListener('resize', measure)
      ro.disconnect()
    }
  }, [])

  const meshRef = useRef<any>(null)
  const yaw = useRef(0) // displayed angle (unbounded degrees; 0 = front)
  const target = useRef(0) // where a drag / scroll wants it
  const frame = useRef(0) // index into FRAMES of the earlier of the two frames on screen
  const rest = useRef(0) // seconds she has been still
  const shown = useRef(0) // yaw on the previous rendered frame
  const speed = useRef(0) // current auto-turn speed, deg/s
  const dir = useRef(1) // pingpong direction
  const lastInput = useRef(-1e9) // clock time of the last drag / scroll (set on first frame)
  const now = useRef(0)
  const dragging = useRef(false)
  const pendingScroll = useRef(0)
  const held = useRef<number | null>(null) // dev hook: yaw parked from the console
  const mouse = useRef({ x: 0, y: 0 })
  // her on-screen box in CSS px, for drag hit-testing
  const hit = useRef({ left: 0, right: 0, top: 0, bottom: 0 })

  // Input: drag on her (mouse or touch) and page scroll both turn her by hand.
  useEffect(() => {
    stage.current.still = prefersReducedMotion()
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)')
    const onMotionPref = () => (stage.current.still = mq.matches)
    mq.addEventListener?.('change', onMotionPref)

    // things that keep their own pointer behaviour even when they sit over her
    const BUSY =
      'a, button, input, textarea, select, label, [role="dialog"], .nav-sheet, .nav-sheet-backdrop, .wk-detail-backdrop, .wk-card, .rl-body, .tl-body'
    const root = document.documentElement
    const overHer = (e: PointerEvent) =>
      e.clientX >= hit.current.left &&
      e.clientX <= hit.current.right &&
      e.clientY >= hit.current.top &&
      e.clientY <= hit.current.bottom &&
      !(e.target as Element | null)?.closest?.(BUSY)

    let lastX = 0
    const onDown = (e: PointerEvent) => {
      if (!turn.drag || stage.current.still || e.button !== 0 || !overHer(e)) return
      dragging.current = true
      lastX = e.clientX
      lastInput.current = now.current
      target.current = yaw.current
      root.classList.add('is-turning')
      if (e.pointerType === 'mouse') e.preventDefault() // no text selection while turning
    }
    const onMove = (e: PointerEvent) => {
      mouse.current.x = (e.clientX / window.innerWidth) * 2 - 1
      mouse.current.y = -((e.clientY / window.innerHeight) * 2 - 1)
      if (dragging.current) {
        // pull her front toward the pointer: drag right → she turns to screen-right
        target.current -= (e.clientX - lastX) * turn.dragDegPerPx
        lastX = e.clientX
        lastInput.current = now.current
      } else {
        root.classList.toggle('can-turn', turn.drag && !stage.current.still && overHer(e))
      }
    }
    const onUp = () => {
      if (!dragging.current) return
      dragging.current = false
      lastInput.current = now.current
      root.classList.remove('is-turning')
    }
    let lastY = window.scrollY
    const onScroll = () => {
      pendingScroll.current += window.scrollY - lastY
      lastY = window.scrollY
      scrollTop.current = lastY
    }
    if (import.meta.env.DEV) {
      window.__turntable = { hold: (a) => (held.current = a), release: () => (held.current = null) }
    }
    window.addEventListener('pointerdown', onDown)
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
    window.addEventListener('pointercancel', onUp)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => {
      mq.removeEventListener?.('change', onMotionPref)
      window.removeEventListener('pointerdown', onDown)
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
      window.removeEventListener('pointercancel', onUp)
      window.removeEventListener('scroll', onScroll)
      root.classList.remove('is-turning', 'can-turn')
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Reused objects — no per-frame allocation.
  const offset = useRef(new THREE.Vector3())
  const paraEuler = useRef(new THREE.Euler(0, 0, 0, 'YXZ'))
  const paraQuat = useRef(new THREE.Quaternion())

  useFrame(({ camera, size, clock }, dt) => {
    const mesh = meshRef.current
    if (!mesh) return
    const still = stage.current.still
    const t = clock.elapsedTime
    if (lastInput.current < -1e8) lastInput.current = t // hold the front frame briefly on load
    now.current = t

    // 1) Yaw: by hand while there is input, auto-turn once it has been quiet for a while.
    if (still) {
      yaw.current = target.current = 0
      pendingScroll.current = 0
    } else if (held.current !== null) {
      yaw.current = target.current = held.current
      pendingScroll.current = 0
      lastInput.current = t
    } else {
      if (turn.auto === 'off' && !dragging.current) {
        // Scroll-only: yaw is tied to the scroll position and always turns the same way —
        // a whole number of full turns over the page, so she faces front at the very top
        // and again at the very bottom.
        const max = maxScroll.current
        const turns = Math.max(1, Math.round((max * turn.scrollDegPerPx) / 360))
        target.current = THREE.MathUtils.clamp(scrollTop.current / max, 0, 1) * 360 * turns
        pendingScroll.current = 0
      } else if (pendingScroll.current !== 0) {
        const step = pendingScroll.current * turn.scrollDegPerPx
        target.current += THREE.MathUtils.clamp(step, -turn.maxScrollStep, turn.maxScrollStep)
        pendingScroll.current = 0
        lastInput.current = t
      }

      if (turn.auto === 'off' || dragging.current || t - lastInput.current < turn.resumeAfter) {
        yaw.current += (target.current - yaw.current) * (1 - Math.pow(turn.manualEase, dt))
        speed.current = 0
      } else {
        const full = 360 / turn.secondsPerTurn
        speed.current = Math.min(full, speed.current + (full / turn.rampUp) * dt)
        let v = speed.current
        if (turn.auto === 'pingpong') {
          const [lo, hi] = turn.range
          const w = wrap180(yaw.current)
          if (w > hi + 0.5 || w < lo - 0.5) {
            // left outside the sweep by hand (e.g. showing her back): take the short way in
            const down = w > hi ? w - hi : w + 360 - hi
            const up = w < lo ? lo - w : lo + 360 - w
            dir.current = down <= up ? -1 : 1
          } else {
            // slow into each end, pick up again out of it
            const ahead = dir.current > 0 ? hi - w : w - lo
            const behind = dir.current > 0 ? w - lo : hi - w
            const ease = Math.sqrt(THREE.MathUtils.clamp(Math.min(ahead, behind) / turn.easeZone, 0, 1))
            v *= Math.max(0.06, ease)
            if (ahead < 0.3) dir.current = -dir.current
          }
        } else {
          dir.current = 1
        }
        yaw.current += dir.current * v * dt
        target.current = yaw.current
      }
    }

    // 2) Which two frames she is between, and how far along (t). The frames' angles are
    //    uneven (the source turn eases), so search for the bracketing pair.
    const prevYaw = shown.current
    shown.current = yaw.current
    const y = wrap360(yaw.current)
    let lo = 0
    let hi = N - 1
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1
      if (FRAMES[mid].yaw <= y) lo = mid
      else hi = mid - 1
    }
    const next = (lo + 1) % N
    const span = (next === 0 ? 360 : FRAMES[next].yaw) - FRAMES[lo].yaw
    let tt = THREE.MathUtils.clamp((y - FRAMES[lo].yaw) / span, 0, 1)
    // Once she has stopped, ease onto the nearest real frame: a resting pose is always
    // an untouched frame from the footage, never an in-between.
    rest.current = Math.abs(yaw.current - prevYaw) < 0.002 ? rest.current + dt : 0
    const k = THREE.MathUtils.smoothstep(rest.current, turn.settleAfter, turn.settleAfter + turn.settleTime)
    tt += (Math.round(tt) - tt) * k
    const u = mesh.material.uniforms
    if (lo !== frame.current || u.uA.value !== maps[lo]) {
      frame.current = lo
      u.uA.value = maps[lo]
      u.uB.value = maps[next]
      u.uFlow.value = flows[lo]
    }
    u.uT.value = tt

    mesh.position.y = still ? 0 : Math.sin(t * bob.speed) * bob.amp

    // 3) Camera: looks straight down −z, placed so she fills her slot.
    const cam: any = camera
    const aspect = size.width / size.height
    const narrow = size.width <= NARROW
    const place = narrow ? slot.narrow : slot.wide
    const tanH = Math.tan(THREE.MathUtils.degToRad(slot.fov) / 2)
    // her widest frame is ~0.7 of her height: on wide layouts lower the top until that fits maxWidth
    const top = narrow ? place.top : Math.max(place.top, place.bottom - (slot.maxWidth * aspect) / 0.7)
    const visibleH = subject.height / (place.bottom - top)
    const dist = visibleH / (2 * tanH)
    const halfH = visibleH / 2
    const halfW = halfH * aspect
    const camX = -(2 * place.cx - 1) * halfW
    const camY = subject.height / 2 - (1 - 2 * top) * halfH

    // Focus on her face; the eased mouse orbits the camera around it, so the face stays
    // put on screen and nearer / farther things (the doodles) slide around it.
    const focus = stage.current.focus.set(0, subject.faceY, 0)
    const me = 1 - Math.pow(slot.parallaxEase, dt)
    const sm = stage.current.mouse
    sm.x += ((still ? 0 : mouse.current.x) - sm.x) * me
    sm.y += ((still ? 0 : mouse.current.y) - sm.y) * me
    const pa = THREE.MathUtils.degToRad(slot.parallax)
    paraEuler.current.set(-sm.y * pa * 0.5, -sm.x * pa, 0)
    paraQuat.current.setFromEuler(paraEuler.current)
    offset.current.set(camX - focus.x, camY - focus.y, dist - focus.z).applyQuaternion(paraQuat.current)
    cam.position.copy(focus).add(offset.current)
    cam.quaternion.copy(paraQuat.current)
    if (cam.fov !== slot.fov) {
      cam.fov = slot.fov
      cam.updateProjectionMatrix()
    }
    stage.current.dist = dist

    // her box on screen (a little narrower than the frame), for the drag hit-test
    const pxH = (place.bottom - top) * size.height
    hit.current.top = top * size.height
    hit.current.bottom = place.bottom * size.height
    hit.current.left = place.cx * size.width - pxH * aspect0 * 0.42
    hit.current.right = place.cx * size.width + pxH * aspect0 * 0.42
  })

  return (
    <mesh ref={meshRef}>
      <planeGeometry args={[width, subject.height]} />
      {/* transparent: soft blended edges; the shader discards fully clear pixels */}
      <shaderMaterial
        uniforms={uniforms}
        vertexShader={turnVertex}
        fragmentShader={turnFragment}
        transparent
        toneMapped={false}
      />
    </mesh>
  )
}

// Hand-drawn doodles (stars, sparkles, dots, bursts) floating around her at different
// depths, echoing the character sheet. Drawn to canvas textures at runtime.
function Doodles({ stage }: { stage: MutableRefObject<StageState> }) {
  const palette = {
    pink: '#e8798b',
    green: '#7fb48a',
    orange: '#f2a03d',
    blue: '#4f74d8',
    coral: '#ea7a5c',
    teal: '#3f9fa3',
    cream: '#f6efd9',
    ink: '#2a2d3a',
  }
  const float = { amp: 0.07, speed: 0.5, spin: 0.25, twinkle: 0.12 }

  // kind / colour / position relative to her face [x, y, z] / size.
  // Near her depth they stay crisp; far behind or in front, depth-of-field melts them.
  const items: { kind: string; color: string; p: [number, number, number]; s: number }[] = [
    { kind: 'star', color: palette.pink, p: [-1.22, 0.5, -0.8], s: 0.2 },
    { kind: 'squiggle', color: palette.blue, p: [-1.32, -0.45, -2.0], s: 0.24 },
    { kind: 'ring', color: palette.cream, p: [-1.0, 0.85, -3.2], s: 0.16 },
    { kind: 'dot', color: palette.coral, p: [-1.2, -1.25, 1.0], s: 0.07 },
    { kind: 'star', color: palette.green, p: [1.28, 0.62, -1.3], s: 0.2 },
    { kind: 'star', color: palette.orange, p: [1.12, 0.05, 0.9], s: 0.13 },
    { kind: 'dot', color: palette.blue, p: [1.38, -0.5, -0.5], s: 0.08 },
    { kind: 'sparkle', color: palette.teal, p: [1.05, 0.9, -2.8], s: 0.2 },
    { kind: 'burst', color: palette.orange, p: [1.42, -1.25, -1.7], s: 0.22 },
    { kind: 'sparkle', color: palette.coral, p: [-0.5, 0.92, -4.0], s: 0.26 },
    { kind: 'ring', color: palette.cream, p: [1.32, -1.62, 0.7], s: 0.08 },
  ]

  // One canvas texture per kind + colour.
  const textures = useMemo(() => {
    const cache: Record<string, THREE.Texture> = {}
    const draw = (kind: string, color: string) => {
      const S = 128
      const c = document.createElement('canvas')
      c.width = S
      c.height = S
      const g: any = c.getContext('2d')
      g.translate(S / 2, S / 2)
      g.lineJoin = 'round'
      g.lineCap = 'round'
      g.fillStyle = color
      g.strokeStyle = palette.ink
      g.lineWidth = 7
      if (kind === 'star') {
        g.beginPath()
        for (let i = 0; i < 10; i++) {
          const r = i % 2 === 0 ? 50 : 23
          const a = (i * Math.PI) / 5 - Math.PI / 2
          g.lineTo(Math.cos(a) * r, Math.sin(a) * r)
        }
        g.closePath()
        g.fill()
        g.stroke()
      } else if (kind === 'sparkle') {
        // four-point sparkle with pinched sides
        g.beginPath()
        g.moveTo(0, -56)
        g.quadraticCurveTo(6, -6, 56, 0)
        g.quadraticCurveTo(6, 6, 0, 56)
        g.quadraticCurveTo(-6, 6, -56, 0)
        g.quadraticCurveTo(-6, -6, 0, -56)
        g.fill()
      } else if (kind === 'dot') {
        g.beginPath()
        g.arc(0, 0, 40, 0, Math.PI * 2)
        g.fill()
        g.stroke()
      } else if (kind === 'ring') {
        g.strokeStyle = color
        g.lineWidth = 12
        g.beginPath()
        g.arc(0, 0, 40, 0, Math.PI * 2)
        g.stroke()
      } else if (kind === 'burst') {
        // three little drops fanning out
        for (const a of [-0.55, 0, 0.55]) {
          g.save()
          g.rotate(a)
          g.beginPath()
          g.ellipse(0, -34, 9, 20, 0, 0, Math.PI * 2)
          g.fill()
          g.lineWidth = 5
          g.stroke()
          g.restore()
        }
      } else {
        // squiggle
        g.strokeStyle = color
        g.lineWidth = 9
        g.beginPath()
        g.moveTo(-46, 20)
        g.bezierCurveTo(-30, -40, -8, 44, 6, -6)
        g.bezierCurveTo(16, -40, 36, 30, 46, -18)
        g.stroke()
      }
      const tex = new THREE.CanvasTexture(c)
      tex.colorSpace = THREE.SRGBColorSpace
      tex.anisotropy = 4
      return tex
    }
    for (const it of items) {
      const key = `${it.kind}-${it.color}`
      if (!cache[key]) cache[key] = draw(it.kind, it.color)
    }
    return cache
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  useEffect(() => () => Object.values(textures).forEach((t) => t.dispose()), [textures])

  const refs = useRef<any[]>([])
  useFrame(({ clock }) => {
    const t = stage.current.still ? 0 : clock.elapsedTime
    items.forEach((it, i) => {
      const m = refs.current[i]
      if (!m) return
      const ph = i * 2.399
      m.position.y = subject.faceY + it.p[1] + Math.sin(t * float.speed + ph) * float.amp
      m.rotation.z = Math.sin(t * float.spin + ph) * 0.35
      m.scale.setScalar(it.s * 2 * (1 + Math.sin(t * 1.3 + ph) * float.twinkle))
    })
  })

  return (
    <>
      {items.map((it, i) => (
        <mesh key={i} ref={(m) => (refs.current[i] = m)} position={[it.p[0], subject.faceY + it.p[1], it.p[2]]}>
          <planeGeometry args={[1, 1]} />
          <meshBasicMaterial
            map={textures[`${it.kind}-${it.color}`]}
            transparent
            alphaTest={0.02}
            toneMapped={false}
          />
        </mesh>
      ))}
    </>
  )
}

// Post-processing: DepthOfField → Bloom → SMAA.
// The DoF focus follows her face every frame (autofocus).
function Post({ stage }: { stage: MutableRefObject<StageState> }) {
  const post = {
    bloomIntensity: 0.5,
    bloomThreshold: 0.86,
    dof: true,
    bokeh: 7,
    focusRange: 1.3, // sharp range in world units: all of her, not the far doodles
  }

  const dofRef = useRef<any>(null)
  useFrame(() => {
    const e = dofRef.current
    if (!e) return
    if (e.target) e.target.copy(stage.current.focus)
    e.bokehScale = post.bokeh
    if (e.cocMaterial) e.cocMaterial.focusRange = post.focusRange
  })

  return (
    <EffectComposer multisampling={0} stencilBuffer={false} depthBuffer>
      {(post.dof ? (
        <DepthOfField
          ref={dofRef}
          target={[0, subject.faceY, 0]}
          worldFocusRange={post.focusRange}
          bokehScale={post.bokeh}
          height={480}
        />
      ) : null) as any}
      <Bloom
        mipmapBlur
        intensity={post.bloomIntensity}
        luminanceThreshold={post.bloomThreshold}
        luminanceSmoothing={0.3}
      />
      <SMAA />
    </EffectComposer>
  )
}

// Scene root: gradient backdrop + the turntable subject (with its camera) + doodles + post.
export default function Scene() {
  const stage = useRef<StageState>({
    focus: new THREE.Vector3(0, subject.faceY, 0),
    dist: 7,
    mouse: { x: 0, y: 0 },
    still: false,
  })
  return (
    <>
      <GradientBackground />

      <Suspense fallback={null}>
        <Subject stage={stage} />
        <Doodles stage={stage} />
      </Suspense>

      <Post stage={stage} />
    </>
  )
}

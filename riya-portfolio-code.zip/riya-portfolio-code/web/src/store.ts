import { create } from 'zustand'
import type { WorkListItem } from './data/works'

// Site-wide interaction state: which work detail is open (null = none).
// Lives in the store so anything on the page — a gallery card, a rail thumbnail —
// can open the same full-screen detail.
interface StoreState {
  detail: WorkListItem | null
  openDetail: (item: WorkListItem) => void
  closeDetail: () => void
}

export const useStore = create<StoreState>((set) => ({
  detail: null,
  openDetail: (item) => set({ detail: item }),
  closeDetail: () => set({ detail: null }),
}))

// Dev-only debugging hook: __store.getState() in the console.
declare global {
  interface Window {
    __store?: typeof useStore
  }
}
if (import.meta.env.DEV) window.__store = useStore

import type { ReactNode, Ref } from 'react'
import { motion } from 'framer-motion'
import { RESUME_PDF } from '../data/resume'

// Last screen: contact copy + footer, in the same right-hand column as the rail.
const CONTACT = {
  eyebrow: "Let's work together",
  title: "Let's tell your story.",
  email: 'itsriyagandhi@gmail.com',
  linkedin: 'https://www.linkedin.com/in/itsriyagandhi/',
  whatsapp: 'https://wa.me/918851670664',
  foot: {
    name: 'Riya Gandhi',
    line: 'Journalism-trained · Audience-led · Brand strategy',
    copyright: '© 2026',
    credit: 'Designed and built by Riya',
  },
}

const EASE = [0.22, 1, 0.36, 1]
const containerV = {
  hidden: {},
  show: { transition: { staggerChildren: 0.09, delayChildren: 0.05 } },
}
const itemV = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.75, ease: EASE } },
}

// Simplified single-colour icons (currentColor).
const icon = (children: ReactNode) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    {children}
  </svg>
)
const ICONS = {
  linkedin: icon(
    <>
      <rect x="3" y="3" width="18" height="18" rx="3.5" />
      <path d="M8 10.5V17M8 7.2v.1M12 17v-3.6a2.4 2.4 0 0 1 4.8 0V17M12 10.5V17" />
    </>
  ),
  email: icon(
    <>
      <rect x="3" y="5" width="18" height="14" rx="2.5" />
      <path d="m4 7.5 8 6 8-6" />
    </>
  ),
  whatsapp: icon(
    <>
      <path d="M4 20l1.3-4A8 8 0 1 1 8.2 19z" />
      <path d="M9.2 8.8c-.3 2.6 3.3 6.2 6 6l.9-1.5-1.9-1-.9.8c-1-.5-1.9-1.4-2.4-2.4l.8-.9-1-1.9z" />
    </>
  ),
  resume: icon(
    <>
      <path d="M12 4v11M7.5 11l4.5 4.5 4.5-4.5M5 20h14" />
    </>
  ),
}

export default function Contact({ innerRef }: { innerRef: Ref<HTMLElement> }) {
  const links = [
    { id: 'linkedin', label: 'LinkedIn', href: CONTACT.linkedin, external: true },
    { id: 'email', label: 'Email', href: `mailto:${CONTACT.email}` },
    { id: 'whatsapp', label: 'WhatsApp', href: CONTACT.whatsapp, external: true },
    { id: 'resume', label: 'Résumé', href: RESUME_PDF.href, download: RESUME_PDF.filename },
  ] as const

  return (
    <section className="contact" data-nav="contact" ref={innerRef}>
      <div className="contact-col">
        <motion.div
          className="contact-inner"
          variants={containerV}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: '-10% 0px' }}
        >
          <motion.p className="rl-eyebrow" variants={itemV}>
            {CONTACT.eyebrow}
          </motion.p>
          <motion.h2 className="contact-title" variants={itemV}>
            {CONTACT.title}
          </motion.h2>
          <motion.a className="contact-mail" href={`mailto:${CONTACT.email}`} variants={itemV}>
            {CONTACT.email}
          </motion.a>
          <motion.div className="contact-links" variants={itemV}>
            {links.map((l) => (
              <a
                key={l.id}
                className="btn"
                href={l.href}
                {...('external' in l ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                {...('download' in l ? { download: l.download } : {})}
              >
                {ICONS[l.id]}
                {l.label}
              </a>
            ))}
          </motion.div>
        </motion.div>

        <footer className="site-foot">
          <div className="foot-mark">
            <span className="foot-name">{CONTACT.foot.name}</span>
            <span>
              {CONTACT.foot.line.split(' · ').map((part, i) => (
                <span key={part}>
                  {i > 0 && ' · '}
                  <span className="foot-part">{part}</span>
                </span>
              ))}
            </span>
          </div>
          <div className="foot-fine">
            <span>{CONTACT.foot.copyright}</span>
            <span>{CONTACT.foot.credit}</span>
          </div>
        </footer>
      </div>
    </section>
  )
}

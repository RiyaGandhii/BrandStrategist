import { useEffect, useState } from 'react'
import { motion, AnimatePresence, useTransform, type MotionValue } from 'framer-motion'
import { RESUME_PDF } from '../data/resume'
import { scrollToNav } from './scrollTo'
import { useStore } from '../store'

// Menu entries → data-nav targets (rail chapters in Resume.tsx, cards in works.ts, contact).
const LINKS = [
  { label: 'About', to: 'about' },
  { label: 'Framework', to: 'framework' },
  { label: 'Experience', to: 'experience' },
  { label: 'Podcast', to: 'podcast' },
  { label: 'Work', to: 'work' },
  { label: 'Case Study', to: 'case' },
  { label: 'Writing', to: 'writing' },
  { label: 'Certifications', to: 'certs' },
]
const CONTACT = { label: 'Get in touch', to: 'contact' }

const EASE = [0.22, 1, 0.36, 1]

// Navigation: an inline link row across the top of the first screen (fades out with
// the hero chrome) plus a small Menu button that stays put and opens the full list.
export default function Nav({ chromeOpacity }: { chromeOpacity: MotionValue<number> }) {
  const [open, setOpen] = useState(false)
  // a work detail covers the page: the menu button steps aside for its close button
  const detailOpen = useStore((s) => s.detail !== null)
  // once the inline row has faded it must stop catching clicks
  const inlineEvents = useTransform(chromeOpacity, (v) => (v < 0.1 ? 'none' : 'auto'))

  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open])

  const go = (to: string) => {
    setOpen(false)
    scrollToNav(to)
  }

  return (
    <>
      <motion.nav
        className="nav-inline"
        aria-label="Sections"
        style={{ opacity: chromeOpacity, pointerEvents: inlineEvents }}
      >
        {LINKS.map((l) => (
          <button key={l.to} className="nav-link" onClick={() => go(l.to)}>
            {l.label}
          </button>
        ))}
      </motion.nav>

      <button
        className={`nav-toggle${open ? ' is-open' : ''}${detailOpen ? ' is-hidden' : ''}`}
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        aria-label={open ? 'Close menu' : 'Open menu'}
      >
        <span className="nav-toggle-bars" aria-hidden="true">
          <i />
          <i />
        </span>
        <span>{open ? 'Close' : 'Menu'}</span>
      </button>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              className="nav-sheet-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              onClick={() => setOpen(false)}
            />
            <motion.nav
              className="nav-sheet"
              aria-label="Menu"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ duration: 0.5, ease: EASE }}
            >
              <button className="nav-sheet-brand" onClick={() => go('top')}>
                Riya Gandhi
              </button>
              <ol className="nav-sheet-list">
                {[...LINKS, CONTACT].map((l, i) => (
                  <li key={l.to}>
                    <button className="nav-sheet-link" onClick={() => go(l.to)}>
                      <span className="nav-sheet-no">{String(i + 1).padStart(2, '0')}</span>
                      {l.label}
                    </button>
                  </li>
                ))}
              </ol>
              <a className="btn" href={RESUME_PDF.href} download={RESUME_PDF.filename}>
                Download résumé (PDF)
              </a>
            </motion.nav>
          </>
        )}
      </AnimatePresence>
    </>
  )
}

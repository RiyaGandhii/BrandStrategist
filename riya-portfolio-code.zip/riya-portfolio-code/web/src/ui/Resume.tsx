import type { CSSProperties, ReactNode } from 'react'
import { motion } from 'framer-motion'
import {
  NUMBERS,
  CHANNEL,
  BRANDS_BLOCK,
  ABOUT,
  CAPABILITIES,
  FRAMEWORK,
  CAREER,
  CASE_STUDY,
  EDUCATION,
  type CareerEntry,
} from '../data/resume'
import { useStore } from '../store'

// The right-hand rail: every chapter that scrolls past while the character holds the
// left of the screen. Copy lives in data/resume.ts; this file only lays it out.
// data-nav={id} marks a jump target for the menu (ui/Nav.tsx).

const EASE = [0.22, 1, 0.36, 1]
const containerV = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08, delayChildren: 0.04 } },
}
const itemV = {
  hidden: { opacity: 0, y: 26 },
  show: { opacity: 1, y: 0, transition: { duration: 0.75, ease: EASE } },
}

// A chapter block: staggers its <Item>s in the first time it scrolls into view.
// rl-body hugs the content (the block's bottom padding stays outside it), so on
// phones it can carry the dark card backing that keeps text readable over the scene.
function Block({
  nav,
  className = '',
  children,
}: {
  nav?: string
  className?: string
  children: ReactNode
}) {
  return (
    <motion.div
      className={`rl-block ${className}`}
      data-nav={nav}
      variants={containerV}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: '-12% 0px -12% 0px' }}
    >
      <div className="rl-body">{children}</div>
    </motion.div>
  )
}

function Item({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <motion.div className={className} variants={itemV}>
      {children}
    </motion.div>
  )
}

function Heading({ eyebrow, title }: { eyebrow?: string; title: string }) {
  return (
    <Item className="rl-head">
      {eyebrow && <p className="rl-eyebrow">{eyebrow}</p>}
      <h2 className="rl-title">{title}</h2>
    </Item>
  )
}

function Numbers() {
  return (
    <Block nav="numbers">
      <Heading title={NUMBERS.eyebrow} />
      <Item>
        <p className="rl-text">{NUMBERS.intro}</p>
      </Item>
      <dl className="stat-grid">
        {NUMBERS.stats.map((s) => (
          <Item key={s.label} className="stat">
            <dt className="stat-value">{s.value}</dt>
            <dd className="stat-label">{s.label}</dd>
          </Item>
        ))}
      </dl>
      <Item>
        <p className="rl-fine">{NUMBERS.source}</p>
      </Item>
    </Block>
  )
}

function Channel() {
  const openDetail = useStore((s) => s.openDetail)
  return (
    <Block>
      <Heading eyebrow={CHANNEL.eyebrow} title={CHANNEL.title} />
      <Item>
        <button
          className="rl-figure"
          onClick={() => openDetail({ name: CHANNEL.title, slug: CHANNEL.slug })}
          aria-label={`${CHANNEL.eyebrow}: ${CHANNEL.title}`}
        >
          <img src={CHANNEL.image} alt={CHANNEL.alt} loading="lazy" />
          <span className="rl-figure-cue" aria-hidden="true">
            View <span>↗</span>
          </span>
        </button>
      </Item>

      <Item className="rl-sub">
        <p className="rl-eyebrow">{BRANDS_BLOCK.eyebrow}</p>
        <h3 className="rl-subtitle">{BRANDS_BLOCK.title}</h3>
      </Item>
      <Item>
        <ul className="brand-row">
          {BRANDS_BLOCK.logos.map((b) => (
            <li key={b.name} className="brand-chip" style={{ '--logo-scale': b.scale ?? 1 } as CSSProperties}>
              <img src={b.logo} alt={b.name} loading="lazy" />
            </li>
          ))}
        </ul>
      </Item>
      <Item>
        <p className="rl-text is-muted">{BRANDS_BLOCK.note}</p>
      </Item>
    </Block>
  )
}

function About() {
  return (
    <Block nav="about">
      <Item className="rl-head">
        <p className="rl-eyebrow">{ABOUT.eyebrow}</p>
        <h2 className="rl-title">{ABOUT.title}</h2>
      </Item>
      {ABOUT.paragraphs.map((p, i) => (
        <Item key={i}>
          <p className="rl-text">{p}</p>
        </Item>
      ))}
    </Block>
  )
}

function Capabilities() {
  return (
    <Block nav="skills">
      <Heading eyebrow={CAPABILITIES.eyebrow} title={CAPABILITIES.title} />
      <ol className="cap-list">
        {CAPABILITIES.items.map((c) => (
          <motion.li key={c.title} className="cap" variants={itemV}>
            <span className="cap-no">{c.no}</span>
            <div>
              <h3 className="cap-title">{c.title}</h3>
              <p className="rl-text">{c.body}</p>
              <ul className="tag-row">
                {c.tags.map((t) => (
                  <li key={t} className="wk-badge">
                    {t}
                  </li>
                ))}
              </ul>
            </div>
          </motion.li>
        ))}
      </ol>
    </Block>
  )
}

function Framework() {
  return (
    <Block nav="framework">
      <Heading eyebrow={FRAMEWORK.eyebrow} title={FRAMEWORK.title} />
      <Item>
        <p className="rl-text">{FRAMEWORK.intro}</p>
      </Item>
      <ol className="fw-list">
        {FRAMEWORK.stages.map((s) => (
          <motion.li key={s.no} className="fw-step" variants={itemV}>
            <span className="fw-no">{s.no}</span>
            <div>
              <h3 className="fw-name">{s.name}</h3>
              <p className="rl-text">{s.body}</p>
            </div>
          </motion.li>
        ))}
      </ol>
      <Item className="fw-loop">
        <span className="fw-loop-icon" aria-hidden="true">
          ↻
        </span>
        <div>
          <h3 className="fw-name">{FRAMEWORK.loop.title}</h3>
          <p className="rl-text">{FRAMEWORK.loop.body}</p>
        </div>
      </Item>
    </Block>
  )
}

// One career entry on the timeline.
function CareerItem({ entry }: { entry: CareerEntry }) {
  return (
    <motion.div
      className="tl-entry"
      variants={containerV}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: '-12% 0px -12% 0px' }}
    >
      <motion.span className="tl-dot" variants={itemV} aria-hidden="true" />
      <div className="tl-body">
        <Item className="tl-period">{entry.period}</Item>
        <Item className="tl-head">
          <h3 className="tl-place">{entry.place}</h3>
          {entry.logo && (
            <span className="tl-logo-chip">
              <img src={entry.logo.logo} alt="" loading="lazy" />
            </span>
          )}
        </Item>
        <Item className="tl-sector">{entry.sector}</Item>
        <Item className="tl-role">{entry.role}</Item>
        <motion.ul className="tl-points" variants={itemV}>
          {entry.points.map((p, i) => (
            <li key={i}>{p}</li>
          ))}
        </motion.ul>
      </div>
    </motion.div>
  )
}

function Career() {
  return (
    <div className="rl-group" data-nav="experience">
      <Block className="is-lead">
        <Heading eyebrow={CAREER.eyebrow} title={CAREER.title} />
        <Item>
          <p className="rl-text">{CAREER.intro}</p>
        </Item>
      </Block>
      <div className="timeline">
        {CAREER.entries.map((e) => (
          <CareerItem key={e.place} entry={e} />
        ))}
      </div>
    </div>
  )
}

function CaseStudy() {
  const { insight, craft } = CASE_STUDY
  return (
    <Block nav="case">
      <Heading eyebrow={CASE_STUDY.eyebrow} title={CASE_STUDY.title} />
      <Item>
        <p className="rl-text is-lead">{CASE_STUDY.intro}</p>
      </Item>
      {CASE_STUDY.sections.flatMap((s) => [
        <Item key={s.label} className="case-part">
          <h3 className="case-label">{s.label}</h3>
          <p className="rl-text">{s.body}</p>
        </Item>,
        ...(s.points ?? []).map((pt, i) => (
          <Item key={`${s.label}-${i}`}>
            <p className="rl-text">
              {i + 1}. {pt}
            </p>
          </Item>
        )),
      ])}
      <Item className="case-insight">
        <h3 className="case-label">{insight.label}</h3>
        <p className="rl-text">{insight.body}</p>
      </Item>

      <Item className="rl-sub">
        <p className="rl-eyebrow">{craft.eyebrow}</p>
        <h3 className="rl-subtitle">{craft.title}</h3>
      </Item>
      <Item>
        <p className="rl-text">{craft.body}</p>
      </Item>
    </Block>
  )
}

function Education() {
  return (
    <Block nav="education" className="is-last">
      <Heading eyebrow={EDUCATION.eyebrow} title={EDUCATION.title} />
      <ul className="edu-list">
        {EDUCATION.entries.map((e) => (
          <motion.li key={e.degree} className="edu" variants={itemV}>
            <span className="tl-period">{e.period}</span>
            <h3 className="edu-degree">{e.degree}</h3>
            <p className="tl-role">{e.school}</p>
          </motion.li>
        ))}
      </ul>
    </Block>
  )
}

export default function Resume() {
  return (
    <section className="resume">
      <div className="rail">
        <Numbers />
        <Channel />
        <About />
        <Capabilities />
        <Framework />
        <Career />
        <CaseStudy />
        <Education />
      </div>
    </section>
  )
}

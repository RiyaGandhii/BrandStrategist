import { useEffect, useRef, useState, type Ref } from 'react'
import { motion, AnimatePresence, useScroll, useTransform } from 'framer-motion'
import ReactMarkdown, { defaultUrlTransform } from 'react-markdown'
import remarkGfm from 'remark-gfm'
import rehypeRaw from 'rehype-raw'
import { WORKS, youtubeThumb, type WorkListItem, type WorkSection } from '../data/works'
import { getWorkDoc } from '../data/workDocs'
import { useStore } from '../store'

const EASE = [0.22, 1, 0.36, 1]

// md / frontmatter media uses /works/... and /images/... paths; join them with BASE_URL
// so the site also works when deployed under a subdirectory.
const resolveAsset = (url: string) =>
  /^\/(works|images)\//.test(url) ? `${import.meta.env.BASE_URL}${url.slice(1)}` : url

type OnOpen = (item: WorkListItem) => void

// Card thumbnail: YouTube still (with a play badge) or a local image.
function Thumb({ item }: { item: WorkListItem }) {
  const src = item.video ? youtubeThumb(item.video) : item.image
  return (
    <span className={`wk-thumb${item.video ? ' is-video' : ''}`}>
      {src && <img src={src} alt="" loading="lazy" />}
      {item.video && (
        <span className="wk-play" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M8 5.5v13l11-6.5z" />
          </svg>
        </span>
      )}
    </span>
  )
}

// 'feature': lede + stats on the left, one big video + notes on the right.
function FeatureBody({ section, onOpen }: { section: WorkSection; onOpen: OnOpen }) {
  const item = section.items[0]
  return (
    <div className="wk-card-body">
      <div className="wk-feature">
        <div className="wk-feature-copy">
          {section.lede && <p className="wk-lede">{section.lede}</p>}
          {section.stats && (
            <dl className="wk-stats">
              {section.stats.map((s) => (
                <div key={s.label} className="wk-stat">
                  <dt>{s.value}</dt>
                  <dd>{s.label}</dd>
                </div>
              ))}
            </dl>
          )}
        </div>
        <div className="wk-feature-side">
          {item && (
            <button className="wk-feature-media" onClick={() => onOpen(item)} aria-label={`${WORKS.playLabel}: ${item.name}`}>
              <Thumb item={item} />
              {item.label && <span className="wk-item-label">{item.label}</span>}
            </button>
          )}
          {section.notes && (
            <div className="wk-notes">
              {section.notes.map((n, i) => (
                <p key={i}>{n}</p>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// 'media': one row per work — thumbnail, label, name, description.
function MediaBody({ section, onOpen }: { section: WorkSection; onOpen: OnOpen }) {
  return (
    <div className="wk-card-body">
      <ul className="wk-media-list">
        {section.items.map((it) => (
          <li key={it.name}>
            <button className="wk-media-row" onClick={() => onOpen(it)}>
              <Thumb item={it} />
              <span className="wk-media-text">
                {it.label && <span className="wk-item-label">{it.label}</span>}
                <span className="wk-media-name">{it.name}</span>
                {it.desc && <span className="wk-media-desc">{it.desc}</span>}
              </span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  )
}

// 'list': numbered text rows; an item with a link (and no slug) opens it directly.
function ListBody({ section, onOpen }: { section: WorkSection; onOpen: OnOpen }) {
  return (
    <div className="wk-card-body">
      <ol className="wk-list">
        {section.items.map((it, i) => {
          const inner = (
            <>
              <span className="wk-line-no">{String(i + 1).padStart(2, '0')}</span>
              <span className="wk-line-name">{it.name}</span>
              <span className="wk-line-meta">
                {it.meta && <span className="wk-line-num">{it.meta}</span>}
                <span className="wk-line-arrow" aria-hidden="true">
                  ↗
                </span>
              </span>
            </>
          )
          return (
            <li key={it.name} className="wk-line">
              {it.link && !it.slug ? (
                <a className="wk-line-btn" href={it.link} target="_blank" rel="noopener noreferrer">
                  {inner}
                </a>
              ) : (
                <button className="wk-line-btn" onClick={() => onOpen(it)}>
                  {inner}
                </button>
              )}
            </li>
          )
        })}
      </ol>
    </div>
  )
}

// 'tiles': image tiles side by side (certificates).
function TilesBody({ section, onOpen }: { section: WorkSection; onOpen: OnOpen }) {
  return (
    <div className="wk-card-body">
      <ul className="wk-tiles">
        {section.items.map((it) => (
          <li key={it.name}>
            <button className="wk-tile" onClick={() => onOpen(it)} aria-label={`${WORKS.viewLabel}: ${it.name}`}>
              <Thumb item={it} />
              {it.label && <span className="wk-item-label">{it.label}</span>}
              <span className="wk-media-name">{it.name}</span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  )
}

const BODIES = { feature: FeatureBody, media: MediaBody, list: ListBody, tiles: TilesBody }

// One full-height section card: index + kicker + title + tagline, then the layout body.
function SectionCard({ section, onOpen }: { section: WorkSection; onOpen: OnOpen }) {
  const Body = BODIES[section.layout]
  return (
    <div className={`wk-card is-${section.layout}`} data-nav={section.id}>
      <div className="wk-card-head">
        <span className="wk-card-no">
          {section.no}
          {section.kicker && <span className="wk-card-kicker">{section.kicker}</span>}
        </span>
        <h3 className="wk-card-title">{section.title}</h3>
        <span className="wk-card-tagline">{section.tagline}</span>
      </div>
      <Body section={section} onOpen={onOpen} />
    </div>
  )
}

// Full-screen detail: renders the work's md (player or banner + title + markdown body +
// link). Without an md it falls back to the item's own label / description.
function WorkDetail({ item, onClose }: { item: WorkListItem; onClose: () => void }) {
  const [bannerError, setBannerError] = useState(false)
  const doc = getWorkDoc(item.slug)
  const title = (doc && doc.title) || item.name
  const video = (doc && doc.video) || item.video
  const banner = doc && doc.banner ? resolveAsset(doc.banner) : null
  const link = (doc && doc.link) || item.link
  const linkLabel = (doc && doc.linkLabel) || WORKS.visitLabel
  const tags = (doc && doc.tags) || item.tags
  const sub = (doc && doc.role) || item.label
  const hasTop = Boolean(video) || Boolean(banner && !bannerError)

  return (
    <>
      <motion.div
        className="wk-detail-backdrop"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
        onClick={onClose}
      />
      <motion.div
        className="wk-detail"
        role="dialog"
        aria-modal="true"
        aria-label={title}
        initial={{ opacity: 0, scale: 0.985, y: 8 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.99, y: 6 }}
        transition={{ duration: 0.42, ease: EASE }}
      >
        <button className="wk-detail-close" onClick={onClose} aria-label={WORKS.closeLabel}>
          ✕
        </button>

        {video ? (
          <div className="wk-detail-video">
            <iframe
              src={`https://www.youtube-nocookie.com/embed/${video}?rel=0`}
              title={title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              referrerPolicy="strict-origin-when-cross-origin"
              allowFullScreen
            />
          </div>
        ) : banner && !bannerError ? (
          <div className="wk-detail-banner">
            <img src={banner} alt={title} onError={() => setBannerError(true)} />
          </div>
        ) : null}

        <article className={`wk-detail-article${hasTop ? '' : ' no-top'}`}>
          <header className="wk-detail-head">
            {sub && <div className="wk-detail-sub">{sub}</div>}
            <h3 className="wk-detail-title">{title}</h3>
            {tags && tags.length > 0 && (
              <div className="wk-detail-tags">
                {tags.map((t, i) => (
                  <span key={i} className="wk-badge">
                    {t}
                  </span>
                ))}
              </div>
            )}
          </header>

          {doc && doc.body ? (
            <div className="wk-md">
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                rehypePlugins={[rehypeRaw]}
                urlTransform={(url) => resolveAsset(defaultUrlTransform(url))}
              >
                {doc.body}
              </ReactMarkdown>
            </div>
          ) : (
            item.desc && <p className="wk-detail-desc">{item.desc}</p>
          )}

          {link && (
            <a className="wk-detail-link" href={link} target="_blank" rel="noopener noreferrer">
              {linkLabel} <span aria-hidden="true">↗</span>
            </a>
          )}
        </article>
      </motion.div>
    </>
  )
}

export default function Works({ innerRef }: { innerRef: Ref<HTMLElement> }) {
  const sections = WORKS.sections
  const count = sections.length

  // Open detail lives in the store: gallery cards and rail thumbnails share it.
  const active = useStore((s) => s.detail)
  const openDetail = useStore((s) => s.openDetail)
  const closeDetail = useStore((s) => s.closeDetail)

  // Vertical scroll pinned into a horizontal pan: measure how far the row of cards
  // can travel (px) and map scroll progress onto it.
  const galleryRef = useRef<HTMLDivElement>(null)
  const trackRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: galleryRef,
    offset: ['start start', 'end end'],
  })

  // track width − viewport width = pan distance; re-measured on resize
  const [scrollRange, setScrollRange] = useState(0)
  useEffect(() => {
    const el = trackRef.current
    if (!el) return
    const measure = () => setScrollRange(Math.max(0, el.scrollWidth - window.innerWidth))
    measure()
    const ro = new ResizeObserver(measure)
    ro.observe(el)
    window.addEventListener('resize', measure)
    return () => {
      ro.disconnect()
      window.removeEventListener('resize', measure)
    }
  }, [count])

  // px interpolation (smoother than vw strings); vertical travel maps 1:1 onto the pan
  const x = useTransform(scrollYProgress, [0, 1], [0, -scrollRange])
  // "keep scrolling" hint fades once the pan is nearly done
  const hintOpacity = useTransform(scrollYProgress, [0.85, 1], [1, 0])

  // While a detail is open: lock page scroll, Esc closes
  useEffect(() => {
    if (!active) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && closeDetail()
    window.addEventListener('keydown', onKey)
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', onKey)
      document.body.style.overflow = prev
    }
  }, [active, closeDetail])

  return (
    <section className="works" ref={innerRef}>
      <div
        className="wk-gallery"
        ref={galleryRef}
        style={{ height: `calc(100vh + ${scrollRange}px)` }}
      >
        <div className="wk-gallery-sticky">
          <motion.div className="wk-track" ref={trackRef} style={{ x }}>
            {/* the section heading travels with the cards, as the first panel of the row */}
            <div className="wk-card wk-intro">
              <h2 className="rl-title">{WORKS.title}</h2>
            </div>
            {sections.map((s) => (
              <SectionCard key={s.id} section={s} onOpen={openDetail} />
            ))}
          </motion.div>

          <div className="wk-progress" aria-hidden="true">
            <motion.div className="wk-progress-fill" style={{ scaleX: scrollYProgress }} />
          </div>
          <motion.span className="wk-hint" style={{ opacity: hintOpacity }} aria-hidden="true">
            {WORKS.hint}
          </motion.span>
        </div>
      </div>

      <AnimatePresence>
        {active && (
          <WorkDetail key={active.slug || active.name} item={active} onClose={closeDetail} />
        )}
      </AnimatePresence>
    </section>
  )
}

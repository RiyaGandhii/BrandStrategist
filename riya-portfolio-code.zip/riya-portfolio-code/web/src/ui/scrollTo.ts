// Smooth-scroll to a section tagged data-nav={id} ('top' = start of the page).
//
// Rail chapters are ordinary blocks. Works cards are not: on desktop the gallery is
// pinned and vertical scroll pans the row of cards sideways 1:1, so a card's scroll
// position is the gallery's top plus the card's offset along the track.
export function scrollToNav(id: string) {
  if (id === 'top') {
    window.scrollTo({ top: 0, behavior: 'smooth' })
    return
  }
  const el = document.querySelector<HTMLElement>(`[data-nav="${id}"]`)
  if (!el) return

  const track = el.closest<HTMLElement>('.wk-track')
  const gallery = el.closest<HTMLElement>('.wk-gallery')
  const sticky = gallery?.querySelector<HTMLElement>('.wk-gallery-sticky')
  const pinned = sticky ? getComputedStyle(sticky).position === 'sticky' : false

  let top: number
  if (track && gallery && pinned) {
    const galleryTop = gallery.getBoundingClientRect().top + window.scrollY
    const range = Math.max(0, track.scrollWidth - window.innerWidth)
    // both rects carry the track's current pan, so their difference is the layout offset
    const offset = el.getBoundingClientRect().left - track.getBoundingClientRect().left
    const inset = Math.max(0, (window.innerWidth - el.offsetWidth) / 2)
    top = galleryTop + Math.min(range, Math.max(0, offset - inset))
  } else {
    // land the block's top above the camera's reference line (30%) so its stop is reached
    const lead = el.classList.contains('contact') ? 0 : window.innerHeight * 0.16
    top = el.getBoundingClientRect().top + window.scrollY - lead
  }
  window.scrollTo({ top, behavior: 'smooth' })
}
